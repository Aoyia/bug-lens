"use strict";
(() => {
  // src/domain/storage-policy.ts
  var DEFAULT_STORAGE_POLICY = {
    retentionDays: 14,
    maxSessionBytes: 512 * 1024 * 1024,
    maxResponseBodyBytes: 2 * 1024 * 1024,
    compression: "balanced"
  };
  var DEFAULT_RECORDING_OPTIONS = {
    captureAudio: false,
    captureVideo: true,
    captureScreenshots: true,
    captureConsole: true,
    captureNetwork: true,
    captureNetworkBodies: true,
    privacyMode: "safe",
    mediaTimesliceMs: 1e3,
    maxResponseBodyBytes: DEFAULT_STORAGE_POLICY.maxResponseBodyBytes,
    maxSessionBytes: DEFAULT_STORAGE_POLICY.maxSessionBytes
  };
  function boundedInteger(value, fallback, min, max) {
    const number = typeof value === "number" && Number.isFinite(value) ? Math.round(value) : fallback;
    return Math.min(max, Math.max(min, number));
  }
  function normalizeStoragePolicy(value) {
    return {
      retentionDays: boundedInteger(value?.retentionDays, DEFAULT_STORAGE_POLICY.retentionDays, 1, 365),
      maxSessionBytes: boundedInteger(value?.maxSessionBytes, DEFAULT_STORAGE_POLICY.maxSessionBytes, 16 * 1024 * 1024, 4 * 1024 * 1024 * 1024),
      maxResponseBodyBytes: boundedInteger(value?.maxResponseBodyBytes, DEFAULT_STORAGE_POLICY.maxResponseBodyBytes, 16 * 1024, 64 * 1024 * 1024),
      compression: value?.compression === "quality" || value?.compression === "small" ? value.compression : "balanced"
    };
  }
  function normalizeRecordingOptions(value, policy = DEFAULT_STORAGE_POLICY) {
    return {
      ...DEFAULT_RECORDING_OPTIONS,
      ...value,
      captureVideo: value?.captureVideo !== false,
      captureAudio: Boolean(value?.captureAudio) && value?.captureVideo !== false,
      captureScreenshots: value?.captureScreenshots !== false,
      captureConsole: value?.captureConsole !== false,
      captureNetwork: value?.captureNetwork !== false,
      captureNetworkBodies: value?.captureNetworkBodies !== false && value?.captureNetwork !== false,
      mediaTimesliceMs: boundedInteger(value?.mediaTimesliceMs, 1e3, 250, 1e4),
      maxResponseBodyBytes: boundedInteger(value?.maxResponseBodyBytes, policy.maxResponseBodyBytes, 16 * 1024, 64 * 1024 * 1024),
      maxSessionBytes: boundedInteger(value?.maxSessionBytes, policy.maxSessionBytes, 16 * 1024 * 1024, 4 * 1024 * 1024 * 1024)
    };
  }
  function expiresAt(createdAtEpochMs, retentionDays) {
    return createdAtEpochMs + retentionDays * 24 * 60 * 60 * 1e3;
  }
  function isExpired(createdAtEpochMs, retentionDays, now = Date.now()) {
    return expiresAt(createdAtEpochMs, retentionDays) <= now;
  }
  function estimateBytes(value) {
    const seen = /* @__PURE__ */ new WeakSet();
    const measure = (current) => {
      if (current == null) return 0;
      if (typeof current === "string") return new TextEncoder().encode(current).byteLength;
      if (typeof current === "number" || typeof current === "boolean") return 8;
      if (current instanceof ArrayBuffer) return current.byteLength;
      if (ArrayBuffer.isView(current)) return current.byteLength;
      if (Array.isArray(current)) return current.reduce((total, item) => total + measure(item), 0);
      if (typeof current === "object") {
        if (seen.has(current)) return 0;
        seen.add(current);
        return Object.entries(current).reduce((total, [key, item]) => total + new TextEncoder().encode(key).byteLength + measure(item), 0);
      }
      return 0;
    };
    return measure(value);
  }

  // src/storage/db.ts
  var DB_NAME = "web-bug-recorder";
  var DB_VERSION = 5;
  var openPromise;
  function openDb() {
    if (openPromise) return openPromise;
    openPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        const transaction = request.transaction;
        if (!transaction) throw new Error("IndexedDB \u6570\u636E\u5E93\u5347\u7EA7/\u8FC1\u79FB\u4E8B\u52A1\u4E0D\u53EF\u7528");
        const ensureStore = (name, keyPath, indexes = []) => {
          const store = database.objectStoreNames.contains(name) ? transaction.objectStore(name) : database.createObjectStore(name, { keyPath });
          for (const index of indexes) {
            if (!store.indexNames.contains(index.name)) store.createIndex(index.name, index.keyPath);
          }
        };
        ensureStore("control", "key");
        ensureStore("sessions", "id", [{ name: "status", keyPath: "status" }]);
        ensureStore("interactions", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("consoleEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("networkEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("mediaChunks", "id", [
          { name: "sessionId", keyPath: "sessionId" },
          { name: "sessionIdSequence", keyPath: ["sessionId", "sequence"] }
        ]);
        ensureStore("exportSelections", "sessionId");
        ensureStore("exportArtifacts", "sessionId");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return openPromise;
  }
  async function put(storeName, value) {
    const db2 = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db2.transaction(storeName, "readwrite");
      tx.objectStore(storeName).put(value);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async function get(storeName, key) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function list(storeName, indexName, key) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).index(indexName).getAll(key);
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }
  async function listAll(storeName) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).getAll();
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }
  async function update(storeName, key, mutate) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      let next;
      const request = store.get(key);
      request.onsuccess = () => {
        const current = request.result;
        if (!current) return;
        try {
          next = mutate(current);
          store.put(next);
        } catch (error) {
          tx.abort();
          reject(error);
        }
      };
      request.onerror = () => reject(request.error);
      tx.oncomplete = () => resolve(next);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error(`\u66F4\u65B0 ${storeName} \u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62`));
    });
  }
  async function listMediaChunkBatch(sessionId, afterSequence, limit) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction("mediaChunks");
      const index = tx.objectStore("mediaChunks").index("sessionIdSequence");
      const range = IDBKeyRange.bound(
        [sessionId, Math.max(0, afterSequence)],
        [sessionId, Number.MAX_SAFE_INTEGER],
        afterSequence >= 0,
        false
      );
      const records = [];
      const request = index.openCursor(range);
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor || records.length >= limit) {
          resolve(records);
          return;
        }
        records.push(cursor.value);
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  }
  async function getMediaSummary(sessionId) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction("mediaChunks");
      const index = tx.objectStore("mediaChunks").index("sessionIdSequence");
      const range = IDBKeyRange.bound([sessionId, 0], [sessionId, Number.MAX_SAFE_INTEGER]);
      const countRequest = index.count(range);
      const firstRequest = index.openCursor(range);
      let count;
      let mimeType;
      const finish = () => {
        if (count != null && firstRequest.readyState === "done") resolve({ count, mimeType });
      };
      countRequest.onsuccess = () => {
        count = countRequest.result;
        finish();
      };
      countRequest.onerror = () => reject(countRequest.error);
      firstRequest.onsuccess = () => {
        const first = firstRequest.result?.value;
        mimeType = first?.mimeType;
        finish();
      };
      firstRequest.onerror = () => reject(firstRequest.error);
    });
  }
  function hasIssue(session, source) {
    return session.quality.issues.some((entry) => entry.source === source);
  }
  function enabledState(enabled, count, failed, detail) {
    if (!enabled) return "disabled";
    if (failed && count === 0) return "failed";
    if (failed) return "partial";
    return "captured";
  }
  async function measureSessionBytes(sessionId) {
    const [interactions, consoleEntries, networkEntries, chunks] = await Promise.all([
      list("interactions", "sessionId", sessionId),
      list("consoleEntries", "sessionId", sessionId),
      list("networkEntries", "sessionId", sessionId),
      list("mediaChunks", "sessionId", sessionId)
    ]);
    return [...interactions, ...consoleEntries, ...networkEntries, ...chunks].reduce((total, entry) => total + estimateBytes(entry), 0);
  }
  async function evidenceFor(session) {
    const [media, networkEntries] = await Promise.all([getMediaSummary(session.id), list("networkEntries", "sessionId", session.id)]);
    const screenshotCount = session.quality.primaryScreenshotCount + session.quality.fallbackScreenshotCount;
    const unavailableScreenshots = session.quality.unavailableScreenshotCount;
    const networkBodyEntries = networkEntries.filter((entry) => entry.response);
    const bodyBytes = networkBodyEntries.reduce((total, entry) => total + (entry.response?.capturedByteLength ?? entry.response?.byteLength ?? 0), 0);
    const redactedBodyCount = networkBodyEntries.filter((entry) => entry.response?.bodyStatus === "redacted").length;
    const truncatedBodyCount = networkBodyEntries.filter((entry) => entry.response?.truncated).length;
    const unavailableBodyCount = networkBodyEntries.filter((entry) => entry.response?.bodyStatus === "unavailable" || entry.response?.bodyStatus === "pending").length;
    const videoState = enabledState(session.options.captureVideo, media.count, hasIssue(session, "media"), media.count ? `${media.count} \u4E2A\u5A92\u4F53\u5206\u7247` : "\u6CA1\u6709\u5A92\u4F53\u5206\u7247");
    const screenshotState = !session.options.captureScreenshots ? "disabled" : unavailableScreenshots ? screenshotCount ? "partial" : "failed" : "captured";
    const consoleState = enabledState(session.options.captureConsole, session.quality.consoleEntryCount, hasIssue(session, "debugger"), `${session.quality.consoleEntryCount} \u6761`);
    const networkState = enabledState(session.options.captureNetwork, session.quality.networkEntryCount, hasIssue(session, "debugger"), `${session.quality.networkEntryCount} \u6761`);
    let bodiesState = "disabled";
    if (session.options.captureNetwork && session.options.captureNetworkBodies) {
      bodiesState = redactedBodyCount ? "redacted" : unavailableBodyCount ? networkBodyEntries.length ? "partial" : "failed" : "captured";
    }
    return [
      { kind: "video", state: videoState, count: media.count, sizeBytes: 0, detail: media.count ? `${media.count} \u4E2A WebM \u5206\u7247` : "\u672A\u5199\u5165\u5F55\u50CF" },
      { kind: "audio", state: !session.options.captureAudio ? "disabled" : videoState, count: session.options.captureAudio && media.count ? 1 : 0, sizeBytes: 0, detail: session.options.captureAudio ? "\u4E0E\u6807\u7B7E\u9875\u5F55\u50CF\u590D\u7528\u540C\u4E00 WebM" : "\u672A\u91C7\u96C6" },
      { kind: "screenshots", state: screenshotState, count: screenshotCount, sizeBytes: 0, detail: !session.options.captureScreenshots ? "\u672A\u91C7\u96C6" : unavailableScreenshots ? `${screenshotCount} \u6210\u529F\uFF0C${unavailableScreenshots} \u5931\u8D25` : `${screenshotCount} \u5F20` },
      { kind: "console", state: consoleState, count: session.quality.consoleEntryCount, sizeBytes: 0, detail: `${session.quality.consoleEntryCount} \u6761` },
      { kind: "network", state: networkState, count: session.quality.networkEntryCount, sizeBytes: 0, detail: `${session.quality.networkEntryCount} \u6761` },
      { kind: "networkBodies", state: bodiesState, count: networkBodyEntries.length, sizeBytes: bodyBytes, detail: !session.options.captureNetworkBodies ? "\u672A\u91C7\u96C6" : redactedBodyCount ? `${redactedBodyCount} \u6761\u5DF2\u8131\u654F${truncatedBodyCount ? `\uFF0C${truncatedBodyCount} \u6761\u5DF2\u622A\u65AD` : ""}` : truncatedBodyCount ? `${truncatedBodyCount} \u6761\u5DF2\u622A\u65AD` : `${networkBodyEntries.length} \u6761` }
    ];
  }
  async function putWithinSessionBudget(storeName, value) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction([storeName, "sessions"], "readwrite");
      const store = tx.objectStore(storeName);
      const sessions = tx.objectStore("sessions");
      let result;
      const sessionRequest = sessions.get(value.sessionId);
      sessionRequest.onsuccess = () => {
        const session = sessionRequest.result;
        if (!session) {
          result = { stored: false, usedBytes: 0, limitReached: false };
          return;
        }
        const valueRequest = store.get(value.id ?? value.sessionId);
        valueRequest.onsuccess = () => {
          const previous = valueRequest.result;
          const delta = Math.max(0, estimateBytes(value) - estimateBytes(previous));
          const usedBytes = session.storage?.usedBytes ?? 0;
          const limit = session.options.maxSessionBytes;
          if (usedBytes + delta > limit) {
            sessions.put({ ...session, storage: { usedBytes, limitReached: true } });
            result = { stored: false, usedBytes, limitReached: true };
            return;
          }
          const nextUsedBytes = Math.max(0, usedBytes + estimateBytes(value) - estimateBytes(previous));
          store.put(value);
          sessions.put({ ...session, storage: { usedBytes: nextUsedBytes, limitReached: false } });
          result = { stored: true, usedBytes: nextUsedBytes, limitReached: false };
        };
        valueRequest.onerror = () => reject(valueRequest.error);
      };
      sessionRequest.onerror = () => reject(sessionRequest.error);
      tx.oncomplete = () => result ? resolve(result) : reject(new Error("\u8BC1\u636E\u5199\u5165\u4E8B\u52A1\u672A\u4EA7\u751F\u7ED3\u679C"));
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error("\u8BC1\u636E\u5199\u5165\u4E8B\u52A1\u5DF2\u4E2D\u6B62"));
    });
  }
  async function deleteSessionAndEvidence(sessionId) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const stores = ["sessions", "interactions", "consoleEntries", "networkEntries", "mediaChunks", "exportSelections", "exportArtifacts", "control"];
      const tx = db2.transaction(stores, "readwrite");
      let existed = false;
      const sessions = tx.objectStore("sessions");
      const sessionRequest = sessions.get(sessionId);
      sessionRequest.onsuccess = () => {
        existed = Boolean(sessionRequest.result);
        sessions.delete(sessionId);
      };
      sessionRequest.onerror = () => reject(sessionRequest.error);
      for (const storeName of ["interactions", "consoleEntries", "networkEntries", "mediaChunks"]) {
        const index = tx.objectStore(storeName).index("sessionId");
        const cursorRequest = index.openKeyCursor(IDBKeyRange.only(sessionId));
        cursorRequest.onsuccess = () => {
          const cursor = cursorRequest.result;
          if (!cursor) return;
          tx.objectStore(storeName).delete(cursor.primaryKey);
          cursor.continue();
        };
        cursorRequest.onerror = () => reject(cursorRequest.error);
      }
      tx.objectStore("exportSelections").delete(sessionId);
      tx.objectStore("exportArtifacts").delete(sessionId);
      const activeRequest = tx.objectStore("control").get("active-session");
      activeRequest.onsuccess = () => {
        if (activeRequest.result?.sessionId === sessionId) tx.objectStore("control").delete("active-session");
      };
      activeRequest.onerror = () => reject(activeRequest.error);
      tx.oncomplete = () => resolve(existed);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error("\u4F1A\u8BDD\u5220\u9664\u4E8B\u52A1\u5DF2\u4E2D\u6B62"));
    });
  }
  var db = {
    getSession: (id) => get("sessions", id),
    listSessions: async (limit = 10) => (await listAll("sessions")).sort((left, right) => right.timeline.createdAtEpochMs - left.timeline.createdAtEpochMs).slice(0, Math.max(0, limit)),
    listSessionOverviews: async (query = "") => {
      const normalizedQuery = query.trim().toLocaleLowerCase();
      const [policy, allSessions] = await Promise.all([db.getStoragePolicy(), listAll("sessions")]);
      const sessions = allSessions.filter((session) => !normalizedQuery || [session.target.initialTitle, session.target.initialUrl, session.status, session.id].some((value) => value.toLocaleLowerCase().includes(normalizedQuery))).sort((left, right) => right.timeline.createdAtEpochMs - left.timeline.createdAtEpochMs);
      return Promise.all(sessions.map(async (session) => {
        const sizeBytes = session.storage?.usedBytes ?? await measureSessionBytes(session.id);
        return {
          session,
          evidence: await evidenceFor(session),
          sizeBytes,
          expiresAtEpochMs: expiresAt(session.timeline.createdAtEpochMs, policy.retentionDays)
        };
      }));
    },
    saveSession: (session) => put("sessions", session),
    updateSession: async (id, update2) => {
      const dbInstance = await openDb();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction("sessions", "readwrite");
        const store = tx.objectStore("sessions");
        let next;
        const request = store.get(id);
        request.onsuccess = () => {
          const current = request.result;
          if (!current) return;
          try {
            next = update2(current);
            store.put(next);
          } catch (error) {
            tx.abort();
            reject(error);
          }
        };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => resolve(next);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u66F4\u65B0\u4F1A\u8BDD\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    updateSessionAndClearActive: async (id, update2) => {
      const dbInstance = await openDb();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction(["sessions", "control"], "readwrite");
        const sessions = tx.objectStore("sessions");
        const control = tx.objectStore("control");
        let next;
        const sessionRequest = sessions.get(id);
        sessionRequest.onsuccess = () => {
          const current = sessionRequest.result;
          if (!current) return;
          try {
            next = update2(current);
            sessions.put(next);
          } catch (error) {
            tx.abort();
            reject(error);
          }
        };
        sessionRequest.onerror = () => reject(sessionRequest.error);
        const activeRequest = control.get("active-session");
        activeRequest.onsuccess = () => {
          const active = activeRequest.result;
          if (active?.sessionId === id) control.delete("active-session");
        };
        activeRequest.onerror = () => reject(activeRequest.error);
        tx.oncomplete = () => resolve(next);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u4F1A\u8BDD\u5B8C\u6210\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    getActiveSession: async () => {
      const active = await get("control", "active-session");
      return active?.sessionId ? get("sessions", active.sessionId) : void 0;
    },
    claimSession: async (session) => {
      const dbInstance = await openDb();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction(["control", "sessions"], "readwrite");
        const control = tx.objectStore("control");
        const sessions = tx.objectStore("sessions");
        let result;
        const claim = () => {
          sessions.put(session);
          control.put({ key: "active-session", sessionId: session.id });
          if (session.commandIds?.start) control.put({ key: `command:${session.commandIds.start}`, commandId: session.commandIds.start, kind: "start", sessionId: session.id, createdAtEpochMs: Date.now() });
          result = { session, claimed: true };
        };
        const currentReq = control.get("active-session");
        currentReq.onsuccess = () => {
          const current = currentReq.result;
          if (current?.sessionId) {
            const existingReq = sessions.get(current.sessionId);
            existingReq.onsuccess = () => {
              const existing = existingReq.result;
              if (existing && ["PREPARING", "RECORDING", "DEGRADED", "STOPPING"].includes(existing.status)) {
                result = { session: existing, claimed: false };
              } else {
                claim();
              }
            };
            existingReq.onerror = () => reject(existingReq.error);
            return;
          }
          claim();
        };
        tx.oncomplete = () => result ? resolve(result) : reject(new Error("\u4F1A\u8BDD\u5360\u7528\u4E8B\u52A1\u5DF2\u5B8C\u6210\u4F46\u65E0\u6709\u6548\u7ED3\u679C"));
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u4F1A\u8BDD\u5360\u7528\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    clearActive: async (sessionId) => {
      const dbInstance = await openDb();
      await new Promise((resolve, reject) => {
        const tx = dbInstance.transaction("control", "readwrite");
        const store = tx.objectStore("control");
        const request = store.get("active-session");
        request.onsuccess = () => {
          const current = request.result;
          if (current?.sessionId === sessionId) store.delete("active-session");
        };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u6D3B\u52A8\u4F1A\u8BDD\u6E05\u7406\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    getCommand: (commandId) => get("control", `command:${commandId}`),
    claimCommand: async (command) => {
      const dbInstance = await openDb();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction("control", "readwrite");
        const store = tx.objectStore("control");
        const key = `command:${command.commandId}`;
        let result;
        const request = store.get(key);
        request.onsuccess = () => {
          const existing = request.result;
          if (existing) {
            result = { command: existing, claimed: false };
            return;
          }
          const next = { key, ...command };
          store.put(next);
          result = { command: next, claimed: true };
        };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => result ? resolve(result) : reject(new Error("\u6307\u4EE4\u5360\u7528\u4E8B\u52A1\u5DF2\u5B8C\u6210\u4F46\u65E0\u6709\u6548\u7ED3\u679C"));
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u6307\u4EE4\u5360\u7528\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    getInteraction: (id) => get("interactions", id),
    saveInteraction: (record) => put("interactions", record),
    saveInteractionWithinBudget: (record) => putWithinSessionBudget("interactions", record),
    getInteractions: (sessionId) => list("interactions", "sessionId", sessionId),
    saveConsole: (entry) => put("consoleEntries", entry),
    saveConsoleWithinBudget: (entry) => putWithinSessionBudget("consoleEntries", entry),
    getConsole: (sessionId) => list("consoleEntries", "sessionId", sessionId),
    saveNetwork: (entry) => put("networkEntries", entry),
    saveNetworkWithinBudget: (entry) => putWithinSessionBudget("networkEntries", entry),
    getNetworkEntry: (id) => get("networkEntries", id),
    updateNetworkEntry: (id, mutate) => update("networkEntries", id, mutate),
    updateNetworkEntryWithinBudget: async (id, mutate) => {
      const current = await get("networkEntries", id);
      if (!current) return { stored: false, usedBytes: 0, limitReached: false };
      return putWithinSessionBudget("networkEntries", mutate(current));
    },
    getNetwork: async (sessionId) => (await list("networkEntries", "sessionId", sessionId)).sort((left, right) => left.createdAt - right.createdAt),
    saveMediaChunk: (chunk) => put("mediaChunks", chunk),
    saveMediaChunkWithinBudget: (chunk) => putWithinSessionBudget("mediaChunks", chunk),
    getMediaSummary,
    getMediaChunks: async (sessionId) => (await list("mediaChunks", "sessionId", sessionId)).sort((left, right) => left.sequence - right.sequence),
    iterateMediaChunks: async (sessionId, visitor, batchSize = 16) => {
      let afterSequence = -1;
      let visited = 0;
      const size = Math.max(1, Math.floor(batchSize));
      while (true) {
        const batch = await listMediaChunkBatch(sessionId, afterSequence, size);
        if (!batch.length) return visited;
        for (const chunk of batch) {
          await visitor(chunk);
          afterSequence = chunk.sequence;
          visited += 1;
        }
        if (batch.length < size) return visited;
      }
    },
    getExportSelection: (sessionId) => get("exportSelections", sessionId),
    saveExportSelection: (selection) => put("exportSelections", selection),
    getExportArtifact: (sessionId) => get("exportArtifacts", sessionId),
    saveExportArtifact: (artifact) => put("exportArtifacts", artifact),
    getStoragePolicy: async () => {
      const stored = await get("control", "storage-policy");
      return normalizeStoragePolicy(stored?.policy ?? DEFAULT_STORAGE_POLICY);
    },
    saveStoragePolicy: async (policy) => {
      const next = normalizeStoragePolicy(policy);
      await put("control", { key: "storage-policy", policy: next });
      return next;
    },
    getStorageOverview: async () => {
      const [policy, sessions] = await Promise.all([db.getStoragePolicy(), listAll("sessions")]);
      const usedBytes = (await Promise.all(sessions.map((session) => session.storage?.usedBytes ?? measureSessionBytes(session.id)))).reduce((total, value) => total + value, 0);
      const estimate = typeof navigator !== "undefined" && navigator.storage?.estimate ? await navigator.storage.estimate().catch(() => void 0) : void 0;
      return { usedBytes, quotaBytes: estimate?.quota ?? Math.max(usedBytes, policy.maxSessionBytes), sessionCount: sessions.length, policy };
    },
    deleteSession: deleteSessionAndEvidence,
    cleanupExpiredSessions: async (now = Date.now()) => {
      const [policy, sessions, active] = await Promise.all([db.getStoragePolicy(), listAll("sessions"), db.getActiveSession()]);
      const expired = sessions.filter((session) => session.id !== active?.id && isExpired(session.timeline.createdAtEpochMs, policy.retentionDays, now));
      await Promise.all(expired.map((session) => deleteSessionAndEvidence(session.id)));
      return expired.map((session) => session.id);
    }
  };

  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 2;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }
  function isEnvelope(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    return candidate.protocolVersion === PROTOCOL_VERSION && typeof candidate.type === "string" && typeof candidate.messageId === "string";
  }

  // src/domain/interaction-ledger.ts
  function applyInteractionEvent(current, event) {
    switch (event.type) {
      case "candidate":
        return current ?? event.interaction;
      case "confirmed":
        if (current?.status === "cancelled") return current;
        return {
          ...event.interaction,
          screenshot: current?.screenshot ?? event.interaction.screenshot
        };
      case "cancelled":
        if (!current) return event.interaction ? { ...event.interaction, status: "cancelled" } : void 0;
        if (current.status === "confirmed" || current.status === "cancelled") return current;
        return { ...current, status: "cancelled" };
      case "screenshot-captured":
        if (!current || current.status === "cancelled") return current;
        return {
          ...current,
          screenshot: {
            status: "captured",
            source: event.source,
            dataUrl: event.dataUrl
          }
        };
      case "screenshot-unavailable":
        if (!current || current.status === "cancelled") return current;
        return {
          ...current,
          screenshot: { status: "unavailable", issue: event.issue }
        };
    }
  }

  // src/domain/recording-session.ts
  var ACTIVE_STATUSES = /* @__PURE__ */ new Set([
    "PREPARING",
    "RECORDING",
    "DEGRADED",
    "STOPPING"
  ]);
  function appendIssue(quality, nextIssue) {
    const duplicate = quality.issues.some((item) => item.code === nextIssue.code && item.message === nextIssue.message);
    return {
      ...quality,
      overall: "partial",
      issues: duplicate ? quality.issues : [...quality.issues, nextIssue]
    };
  }
  function stoppedTimeline(session, stoppedAtEpochMs) {
    const startedAt = session.timeline.startedAtEpochMs ?? session.timeline.createdAtEpochMs;
    return {
      ...session.timeline,
      stoppedAtEpochMs,
      durationMs: Math.max(0, stoppedAtEpochMs - startedAt)
    };
  }
  function applySessionEvent(session, event) {
    switch (event.type) {
      case "started": {
        if (session.status !== "PREPARING" && session.status !== "DEGRADED") return session;
        const quality = (event.issues ?? []).reduce(appendIssue, session.quality);
        const degraded = session.status === "DEGRADED" || quality.issues.length > 0;
        return {
          ...session,
          status: degraded ? "DEGRADED" : "RECORDING",
          timeline: {
            ...session.timeline,
            startedAtEpochMs: session.timeline.startedAtEpochMs ?? event.atEpochMs
          },
          quality
        };
      }
      case "capture-issue":
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        return {
          ...session,
          status: session.status === "PREPARING" || session.status === "RECORDING" ? "DEGRADED" : session.status,
          quality: appendIssue(session.quality, event.issue)
        };
      case "quality-delta": {
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        const quality = { ...session.quality };
        for (const [key, delta] of Object.entries(event.delta)) {
          if (delta != null) quality[key] = Math.max(0, quality[key] + delta);
        }
        return { ...session, quality };
      }
      case "quality-snapshot":
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        return { ...session, quality: { ...session.quality, ...event.counts } };
      case "stop-requested":
        if (session.status === "STOPPING") {
          if (!event.commandId || session.commandIds?.stop === event.commandId) return session;
          if (session.commandIds?.stop) return session;
          return { ...session, commandIds: session.commandIds ? { ...session.commandIds, stop: event.commandId } : void 0 };
        }
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        return {
          ...session,
          status: "STOPPING",
          timeline: {
            ...session.timeline,
            stoppedAtEpochMs: event.atEpochMs
          },
          commandIds: session.commandIds ? { ...session.commandIds, stop: event.commandId ?? session.commandIds.stop } : void 0
        };
      case "stop-completed": {
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        const stoppedAt = event.atEpochMs ?? session.timeline.stoppedAtEpochMs ?? Date.now();
        return {
          ...session,
          status: "PREVIEW_READY",
          timeline: stoppedTimeline(session, stoppedAt),
          quality: event.issue ? appendIssue(session.quality, event.issue) : session.quality
        };
      }
      case "recover":
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        return {
          ...session,
          status: "PREVIEW_READY",
          timeline: stoppedTimeline(session, event.atEpochMs),
          quality: appendIssue(session.quality, event.issue)
        };
      case "failed":
        if (!ACTIVE_STATUSES.has(session.status)) return session;
        return {
          ...session,
          status: "FAILED",
          error: event.issue,
          quality: { ...appendIssue(session.quality, event.issue), overall: "failed" }
        };
    }
  }

  // src/domain/privacy-policy.ts
  var SENSITIVE_HEADER_NAMES = /* @__PURE__ */ new Set([
    "authorization",
    "proxyauthorization",
    "cookie",
    "setcookie",
    "xapikey",
    "apikey",
    "xauthtoken",
    "token",
    "xcsrftoken",
    "xxsrftoken",
    "secret",
    "password"
  ]);
  var URL_HEADER_NAMES = /* @__PURE__ */ new Set(["location", "referer", "referrer", "origin"]);
  var SENSITIVE_JSON_KEY = /(?:password|passwd|passcode|token|authorization|secret|cookie|session|email|phone|address|card|cvv|ssn|dateofbirth|dob)/i;
  var OPAQUE_PATH_SEGMENT = /^(?:[0-9a-f]{8}-[0-9a-f-]{27,}|[^@/]+@[^@/]+\.[^@/]+|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|\d{8,}|[A-Za-z0-9_-]{24,})$/i;
  function normalizeName(value) {
    return value.toLowerCase().replace(/[^a-z0-9]/g, "");
  }
  function sanitizeUrl(value, mode) {
    if (mode === "raw" || !value) return value;
    try {
      const parsed = new URL(value);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "[REDACTED:url]";
      const pathname = parsed.pathname.split("/").map((segment) => {
        let decoded = segment;
        try {
          decoded = decodeURIComponent(segment);
        } catch {
        }
        return OPAQUE_PATH_SEGMENT.test(decoded) ? "[ID]" : segment;
      }).join("/");
      const queryKeys = [];
      parsed.searchParams.forEach((_value, key) => {
        if (!queryKeys.includes(key)) queryKeys.push(key);
      });
      const query = queryKeys.map((key) => `${encodeURIComponent(key)}=[REDACTED]`).join("&");
      return `${parsed.protocol}//${parsed.host}${pathname}${query ? `?${query}` : ""}`;
    } catch {
      const withoutFragment = value.split("#", 1)[0];
      const withoutCredentials = withoutFragment.replace(/^(https?:\/\/)(?:[^/@\s]+@)/i, "$1");
      return withoutCredentials.replace(/([?&][^=&#\s]+)=([^&#\s]*)/g, "$1=[REDACTED]").slice(0, 2048);
    }
  }
  function sanitizeText(value, mode, maxLength = 8192, sanitizeUrls = true) {
    if (mode === "raw") return value;
    let result = String(value ?? "");
    if (sanitizeUrls) {
      result = result.replace(/https?:\/\/[^\s<>"']+/gi, (url) => sanitizeUrl(url, mode));
    }
    result = result.replace(/-----BEGIN [^-]+-----[\s\S]*?-----END [^-]+-----/g, "[REDACTED:pem]").replace(/data:[^\s,;]+(?:;[^\s,]*)?,[^\s]+/gi, "[REDACTED:data-url]").replace(/\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+/gi, (match) => `${match.split(/\s/, 1)[0]} [REDACTED]`).replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, "[REDACTED:jwt]").replace(/\b(password|passwd|passcode|token|access[_-]?token|refresh[_-]?token|secret|api[_-]?key)(\s*[:=]\s*)[^\s,;&]+/gi, (_match, key, separator) => `${key}${separator}[REDACTED]`).replace(/(["'])(password|passwd|passcode|token|access[_-]?token|refresh[_-]?token|secret|api[_-]?key|authorization|cookie|session|email|phone|address|card|cvv|ssn)(\1\s*:\s*)(["'])(?:\\.|(?!\4).)*\4/gi, (_match, quote, key, separator, valueQuote) => `${quote}${key}${separator}${valueQuote}[REDACTED]${valueQuote}`).replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[REDACTED:email]").replace(/\b(?:\d[ -]*?){13,19}\b/g, "[REDACTED:card]");
    if (result.length > maxLength) result = `${result.slice(0, maxLength)}
[TRUNCATED]`;
    return result;
  }
  function sanitizeHeaders(headers, mode) {
    if (!headers) return void 0;
    return Object.fromEntries(Object.entries(headers).map(([key, rawValue]) => {
      const value = String(rawValue);
      if (mode === "raw") return [key, value];
      const normalized = normalizeName(key);
      if (SENSITIVE_HEADER_NAMES.has(normalized)) return [key, `[REDACTED:${key}]`];
      if (URL_HEADER_NAMES.has(normalized)) return [key, sanitizeUrl(value, mode)];
      return [key, sanitizeText(value, mode, 4096)];
    }));
  }
  function sanitizeResponseBody(input) {
    const byteLength = input.base64Encoded ? Math.max(0, Math.floor(input.body.length * 3 / 4) - (input.body.endsWith("==") ? 2 : input.body.endsWith("=") ? 1 : 0)) : new TextEncoder().encode(input.body).byteLength;
    const maxBytes = Math.max(16 * 1024, input.maxBytes ?? Number.MAX_SAFE_INTEGER);
    const truncate = (value) => {
      const bytes = new TextEncoder().encode(value);
      if (bytes.byteLength <= maxBytes) return { value, truncated: false, byteLength: bytes.byteLength };
      const marker = "\n[TRUNCATED]";
      return { value: `${new TextDecoder().decode(bytes.slice(0, Math.max(0, maxBytes - marker.length)))}${marker}`, truncated: true, byteLength: maxBytes };
    };
    if (input.mode === "raw") {
      if (input.base64Encoded) {
        const maxCharacters = Math.max(4, Math.floor(maxBytes * 4 / 3 / 4) * 4);
        const body3 = input.body.length > maxCharacters ? input.body.slice(0, maxCharacters) : input.body;
        return { bodyStatus: "captured", body: body3, base64Encoded: true, byteLength, originalByteLength: byteLength, capturedByteLength: Math.floor(body3.length * 3 / 4), truncated: body3.length < input.body.length };
      }
      const body2 = truncate(input.body);
      return { bodyStatus: "captured", body: body2.value, base64Encoded: false, byteLength, originalByteLength: byteLength, capturedByteLength: body2.byteLength, truncated: body2.truncated };
    }
    if (input.base64Encoded) {
      return { bodyStatus: "redacted", byteLength, originalByteLength: byteLength, capturedByteLength: 0, redactionReason: "binary-body" };
    }
    let body;
    if (input.mimeType?.includes("json") || /^[\s]*[\[{]/.test(input.body)) {
      try {
        const redactValue = (value, depth = 0) => {
          if (depth > 30) return "[REDACTED:depth-limit]";
          if (Array.isArray(value)) return value.map((item) => redactValue(item, depth + 1));
          if (value && typeof value === "object") {
            const result = {};
            for (const [key, child] of Object.entries(value)) {
              if (["__proto__", "prototype", "constructor"].includes(key)) continue;
              result[key] = SENSITIVE_JSON_KEY.test(normalizeName(key)) ? `[REDACTED:${key}]` : redactValue(child, depth + 1);
            }
            return result;
          }
          return typeof value === "string" ? sanitizeText(value, "safe", 8192) : value;
        };
        body = JSON.stringify(redactValue(JSON.parse(input.body)));
      } catch {
        body = sanitizeText(input.body, "safe", 262144);
      }
    } else {
      body = sanitizeText(input.body, "safe", 262144);
    }
    const captured = truncate(body);
    return { bodyStatus: "captured", body: captured.value, base64Encoded: false, byteLength, originalByteLength: byteLength, capturedByteLength: captured.byteLength, truncated: captured.truncated };
  }
  function sanitizeInteractionRecord(record, mode) {
    if (mode === "raw") return record;
    const attributes = Object.fromEntries(Object.entries(record.element.attributes).map(([key, value]) => [
      key,
      /^(?:href|src|action|formaction)$/i.test(key) ? sanitizeUrl(value, mode) : sanitizeText(value, mode, 512)
    ]));
    return {
      ...record,
      page: {
        ...record.page,
        url: sanitizeUrl(record.page.url, mode),
        title: sanitizeText(record.page.title, mode, 256)
      },
      element: {
        ...record.element,
        id: record.element.id ? sanitizeText(record.element.id, mode, 128) : void 0,
        classNames: record.element.classNames.map((value) => sanitizeText(value, mode, 128)),
        attributes,
        text: record.element.text ? sanitizeText(record.element.text, mode, 256) : void 0,
        accessibleName: record.element.accessibleName ? sanitizeText(record.element.accessibleName, mode, 256) : void 0,
        locators: record.element.locators.map((locator) => ({
          ...locator,
          expression: sanitizeText(locator.expression, mode, 512),
          reasons: locator.reasons.map((reason) => sanitizeText(reason, mode, 256))
        }))
      }
    };
  }
  function sanitizeConsoleEntry(entry, mode) {
    if (mode === "raw") return entry;
    return {
      ...entry,
      text: sanitizeText(entry.text, mode, 8192),
      source: entry.source ? sanitizeUrl(entry.source, mode) : void 0
    };
  }

  // src/domain/evidence-clock.ts
  function networkRequestTime(timing, now = Date.now) {
    return {
      createdAtEpochMs: typeof timing.wallTime === "number" ? Math.round(timing.wallTime * 1e3) : now(),
      startedAtMonotonicMs: typeof timing.timestamp === "number" ? Math.round(timing.timestamp * 1e3) : void 0
    };
  }
  function networkDurationMs(startedAtMonotonicMs, finishedTimestampSeconds) {
    if (startedAtMonotonicMs == null || finishedTimestampSeconds == null) return void 0;
    const finishedAtMonotonicMs = finishedTimestampSeconds * 1e3;
    const duration = finishedAtMonotonicMs - startedAtMonotonicMs;
    return duration >= 0 ? Math.round(duration) : void 0;
  }

  // src/evidence/cdp-evidence-collector.ts
  function withTimeout(promise, timeoutMs, messageText) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(messageText)), timeoutMs);
      promise.then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (error) => {
          clearTimeout(timer);
          reject(error);
        }
      );
    });
  }
  function captureIssue(code, message2, source = "debugger") {
    return { code, message: message2, source, recoverable: true, occurredAt: Date.now() };
  }
  var CdpEvidenceCollector = class {
    constructor(repository, writeSessionEvent, isStopping) {
      this.repository = repository;
      this.writeSessionEvent = writeSessionEvent;
      this.isStopping = isStopping;
    }
    repository;
    writeSessionEvent;
    isStopping;
    attachedTabs = /* @__PURE__ */ new Set();
    pendingBodyCaptures = /* @__PURE__ */ new Set();
    eventQueues = /* @__PURE__ */ new Map();
    pendingHandlers = /* @__PURE__ */ new Set();
    markAttached(tabId) {
      this.attachedTabs.add(tabId);
    }
    async attach(tabId, session) {
      try {
        await chrome.debugger.attach({ tabId }, "1.3");
        this.attachedTabs.add(tabId);
        if (session.options.captureConsole) {
          await chrome.debugger.sendCommand({ tabId }, "Runtime.enable");
          await chrome.debugger.sendCommand({ tabId }, "Log.enable").catch(() => void 0);
        }
        if (session.options.captureNetwork) {
          await chrome.debugger.sendCommand({ tabId }, "Network.enable", {
            maxTotalBufferSize: 50 * 1024 * 1024,
            maxResourceBufferSize: 10 * 1024 * 1024,
            maxPostDataSize: 1024 * 1024
          }).catch(() => void 0);
        }
        return void 0;
      } catch (error) {
        return captureIssue("DEBUGGER_ATTACH_FAILED", sanitizeText(String(error), session.options.privacyMode));
      }
    }
    async detach(tabId) {
      this.attachedTabs.delete(tabId);
      await chrome.debugger.detach({ tabId }).catch(() => void 0);
    }
    handleEvent(source, method, params) {
      const tabId = source.tabId;
      if (typeof tabId !== "number") return;
      const task = this.processEvent(source, tabId, method, params);
      this.pendingHandlers.add(task);
      void task.then(
        () => this.pendingHandlers.delete(task),
        () => this.pendingHandlers.delete(task)
      );
    }
    async handleDetach(source, reason) {
      if (typeof source.tabId !== "number" || reason === "target_closed") return;
      this.attachedTabs.delete(source.tabId);
      const session = await this.repository.getActiveSession();
      if (!session || session.status === "STOPPING" || this.isStopping(session.id) || session.target.tabId !== source.tabId) return;
      await this.writeSessionEvent(session.id, {
        type: "capture-issue",
        issue: captureIssue("DEBUGGER_DETACHED_BY_DEVTOOLS", reason)
      });
    }
    async drain() {
      const errors = [];
      for (let round = 0; round < 3 && this.pendingHandlers.size; round += 1) {
        const results = await Promise.allSettled([...this.pendingHandlers]);
        for (const result of results) if (result.status === "rejected") errors.push(`\u8C03\u8BD5\u4E8B\u4EF6\u5199\u5165\u672A\u5B8C\u6210\uFF1A${String(result.reason)}`);
      }
      for (let round = 0; round < 3 && this.eventQueues.size; round += 1) {
        const results = await Promise.allSettled([...this.eventQueues.values()]);
        for (const result of results) if (result.status === "rejected") errors.push(`Network \u5199\u5165\u672A\u5B8C\u6210\uFF1A${String(result.reason)}`);
      }
      return errors;
    }
    async finalizeNetworkBodies(session) {
      if (!session.options.captureNetworkBodies) return;
      for (let round = 0; round < 3 && this.pendingBodyCaptures.size; round += 1) {
        await Promise.allSettled([...this.pendingBodyCaptures]);
      }
      const pending = (await this.repository.getNetwork(session.id)).filter((entry) => entry.response?.bodyStatus === "pending");
      let cursor = 0;
      const deadline = Date.now() + 5e3;
      const workers = Array.from({ length: Math.min(4, pending.length) }, async () => {
        while (cursor < pending.length && Date.now() < deadline) {
          const entry = pending[cursor++];
          const requestId = entry.id.startsWith(`${session.id}:`) ? entry.id.slice(session.id.length + 1) : "";
          if (requestId) await this.captureResponseBody({ tabId: session.target.tabId }, session, requestId);
        }
      });
      await Promise.allSettled(workers);
      const unresolved = (await this.repository.getNetwork(session.id)).filter((entry) => entry.response?.bodyStatus === "pending");
      await Promise.all(unresolved.map((entry) => this.repository.updateNetworkEntry(entry.id, (current) => ({
        ...current,
        response: {
          ...current.response,
          bodyStatus: "unavailable",
          error: "RESPONSE_BODY_INCOMPLETE: \u5F55\u5236\u7ED3\u675F\u524D\u672A\u6536\u5230\u5B8C\u6574\u54CD\u5E94\u6216\u6D4F\u89C8\u5668\u672A\u63D0\u4F9B\u6B63\u6587"
        }
      }))));
    }
    enqueue(key, work) {
      const previous = this.eventQueues.get(key) ?? Promise.resolve();
      const current = previous.catch(() => void 0).then(work);
      this.eventQueues.set(key, current);
      void current.then(
        () => {
          if (this.eventQueues.get(key) === current) this.eventQueues.delete(key);
        },
        () => {
          if (this.eventQueues.get(key) === current) this.eventQueues.delete(key);
        }
      );
      return current;
    }
    trackBodyCapture(task) {
      this.pendingBodyCaptures.add(task);
      void task.then(
        () => this.pendingBodyCaptures.delete(task),
        () => this.pendingBodyCaptures.delete(task)
      );
    }
    async captureResponseBody(source, session, requestId) {
      const id = `${session.id}:${requestId}`;
      const current = await this.repository.getNetworkEntry(id);
      if (!current) return;
      if (current.method === "HEAD" || current.status === 204 || current.status === 304) {
        await this.repository.updateNetworkEntry(id, (entry) => ({ ...entry, response: { ...entry.response, bodyStatus: "not-present" } }));
        return;
      }
      try {
        const command = chrome.debugger.sendCommand(source, "Network.getResponseBody", { requestId });
        const result = await withTimeout(command, 3e3, "RESPONSE_BODY_TIMEOUT: \u54CD\u5E94\u6B63\u6587\u8BFB\u53D6\u8D85\u8FC7 3 \u79D2");
        const rawBody = result.body ?? "";
        const base64Encoded = Boolean(result.base64Encoded);
        const sanitized = sanitizeResponseBody({ body: rawBody, base64Encoded, mimeType: current.response?.mimeType, mode: session.options.privacyMode, maxBytes: session.options.maxResponseBodyBytes });
        const stored = await this.repository.updateNetworkEntryWithinBudget(id, (entry) => ({ ...entry, response: { ...entry.response, ...sanitized } }));
        if (!stored.stored) await this.writeSessionEvent(session.id, { type: "capture-issue", issue: captureIssue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A Network \u6B63\u6587\u3002", "storage") });
      } catch (error) {
        await this.repository.updateNetworkEntry(id, (entry) => ({
          ...entry,
          response: { ...entry.response, bodyStatus: "unavailable", error: sanitizeText(String(error), session.options.privacyMode) }
        }));
      }
    }
    async processEvent(source, tabId, method, params) {
      const session = await this.repository.getActiveSession();
      if (!session || !["PREPARING", "RECORDING", "DEGRADED"].includes(session.status) || this.isStopping(session.id) || session.target.tabId !== tabId) return;
      if (session.options.captureConsole && method === "Runtime.consoleAPICalled") {
        const value = params;
        const stored = await this.repository.saveConsoleWithinBudget(sanitizeConsoleEntry({
          id: crypto.randomUUID(),
          sessionId: session.id,
          createdAt: value.timestamp ?? Date.now(),
          level: value.type ?? "log",
          text: (value.args ?? []).map((arg) => typeof arg.value === "string" ? arg.value : arg.description ?? String(arg.value ?? "")).join(" ")
        }, session.options.privacyMode));
        if (stored.stored) await this.writeSessionEvent(session.id, { type: "quality-delta", delta: { consoleEntryCount: 1 } });
        else await this.writeSessionEvent(session.id, { type: "capture-issue", issue: captureIssue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A Console \u65E5\u5FD7\u3002", "storage") });
        return;
      }
      if (session.options.captureConsole && method === "Runtime.exceptionThrown") {
        const value = params;
        const details = value.exceptionDetails;
        const stored = await this.repository.saveConsoleWithinBudget(sanitizeConsoleEntry({
          id: crypto.randomUUID(),
          sessionId: session.id,
          createdAt: value.timestamp ?? Date.now(),
          level: "error",
          text: details?.exception?.description ?? details?.text ?? "\u672A\u6355\u83B7\u5F02\u5E38",
          source: details?.url
        }, session.options.privacyMode));
        if (stored.stored) await this.writeSessionEvent(session.id, { type: "quality-delta", delta: { consoleEntryCount: 1 } });
        else await this.writeSessionEvent(session.id, { type: "capture-issue", issue: captureIssue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A Console \u65E5\u5FD7\u3002", "storage") });
        return;
      }
      if (session.options.captureConsole && method === "Log.entryAdded") {
        const value = params;
        if (!value.entry) return;
        const stored = await this.repository.saveConsoleWithinBudget(sanitizeConsoleEntry({
          id: crypto.randomUUID(),
          sessionId: session.id,
          createdAt: value.entry.timestamp ?? Date.now(),
          level: value.entry.level ?? "info",
          text: value.entry.text ?? "",
          source: value.entry.url
        }, session.options.privacyMode));
        if (stored.stored) await this.writeSessionEvent(session.id, { type: "quality-delta", delta: { consoleEntryCount: 1 } });
        else await this.writeSessionEvent(session.id, { type: "capture-issue", issue: captureIssue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A Console \u65E5\u5FD7\u3002", "storage") });
        return;
      }
      if (session.options.captureNetwork && method === "Network.requestWillBeSent") {
        const value = params;
        if (!value.request?.url) return;
        const requestId2 = value.requestId ?? crypto.randomUUID();
        await this.enqueue(`${tabId}:${requestId2}`, async () => {
          const timing = networkRequestTime({ timestamp: value.timestamp, wallTime: value.wallTime });
          const stored = await this.repository.saveNetworkWithinBudget({
            id: `${session.id}:${requestId2}`,
            sessionId: session.id,
            createdAt: timing.createdAtEpochMs,
            startedAtMonotonicMs: timing.startedAtMonotonicMs,
            url: sanitizeUrl(value.request.url, session.options.privacyMode),
            method: value.request.method ?? "GET",
            type: value.type
          });
          if (stored.stored) await this.writeSessionEvent(session.id, { type: "quality-delta", delta: { networkEntryCount: 1 } });
          else await this.writeSessionEvent(session.id, { type: "capture-issue", issue: captureIssue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A Network \u8BB0\u5F55\u3002", "storage") });
        });
        return;
      }
      if (!session.options.captureNetwork) return;
      const requestId = params?.requestId;
      if (!requestId) return;
      const id = `${session.id}:${requestId}`;
      if (method === "Network.responseReceived") {
        const value = params;
        await this.enqueue(`${tabId}:${requestId}`, () => this.repository.updateNetworkEntry(id, (current) => ({
          ...current,
          status: value.response?.status,
          response: {
            mimeType: value.response?.mimeType,
            headers: sanitizeHeaders(value.response?.headers, session.options.privacyMode),
            bodyStatus: "pending"
          }
        })).then(() => void 0));
      } else if (method === "Network.loadingFinished") {
        const value = params;
        this.trackBodyCapture(this.enqueue(`${tabId}:${requestId}`, async () => {
          await this.repository.updateNetworkEntry(id, (current) => ({
            ...current,
            durationMs: networkDurationMs(current.startedAtMonotonicMs, value.timestamp)
          }));
          if (session.options.captureNetworkBodies) await this.captureResponseBody(source, session, requestId);
          else await this.repository.updateNetworkEntry(id, (current) => ({ ...current, response: { ...current.response, bodyStatus: "not-present" } }));
        }));
      } else if (method === "Network.loadingFailed") {
        const value = params;
        const safeError = sanitizeText(value.errorText ?? "\u8BF7\u6C42\u5931\u8D25", session.options.privacyMode);
        await this.enqueue(`${tabId}:${requestId}`, () => this.repository.updateNetworkEntry(id, (current) => ({
          ...current,
          durationMs: networkDurationMs(current.startedAtMonotonicMs, value.timestamp),
          error: safeError,
          response: { ...current.response, bodyStatus: "unavailable", error: safeError }
        })).then(() => void 0));
      }
    }
  };

  // src/recording/recording-coordinator.ts
  var RecordingCoordinator = class {
    lifecycleQueue = Promise.resolve();
    stopFlights = /* @__PURE__ */ new Map();
    stoppingSessionIds = /* @__PURE__ */ new Set();
    runLifecycle(work) {
      const current = this.lifecycleQueue.catch(() => void 0).then(work);
      this.lifecycleQueue = current.catch(() => void 0);
      return current;
    }
    runStop(sessionId, work) {
      const existing = this.stopFlights.get(sessionId);
      if (existing) return existing;
      const flight = work();
      this.stopFlights.set(sessionId, flight);
      void flight.then(
        () => {
          if (this.stopFlights.get(sessionId) === flight) this.stopFlights.delete(sessionId);
        },
        () => {
          if (this.stopFlights.get(sessionId) === flight) this.stopFlights.delete(sessionId);
        }
      );
      return flight;
    }
    beginStopping(sessionId) {
      this.stoppingSessionIds.add(sessionId);
    }
    finishStopping(sessionId) {
      this.stoppingSessionIds.delete(sessionId);
    }
    isStopping(sessionId) {
      return this.stoppingSessionIds.has(sessionId);
    }
  };

  // src/entrypoints/background/index.ts
  var EXTENSION_VERSION = "0.1.0";
  var registeredContentScript = false;
  var interactionEventQueues = /* @__PURE__ */ new Map();
  var pendingInteractionHandlers = /* @__PURE__ */ new Set();
  var recordingCoordinator = new RecordingCoordinator();
  var BROWSER_EPOCH_KEY = "bug-lens-browser-epoch";
  var browserEpochPromise = loadOrCreateBrowserEpoch();
  async function loadOrCreateBrowserEpoch() {
    const stored = await chrome.storage.session.get(BROWSER_EPOCH_KEY);
    const existing = stored[BROWSER_EPOCH_KEY];
    if (typeof existing === "string" && existing) return existing;
    const created = crypto.randomUUID();
    await chrome.storage.session.set({ [BROWSER_EPOCH_KEY]: created });
    return created;
  }
  function enqueueInteractionTask(key, work) {
    const previous = interactionEventQueues.get(key) ?? Promise.resolve();
    const current = previous.catch(() => void 0).then(work);
    interactionEventQueues.set(key, current);
    void current.then(
      () => {
        if (interactionEventQueues.get(key) === current) interactionEventQueues.delete(key);
      },
      () => {
        if (interactionEventQueues.get(key) === current) interactionEventQueues.delete(key);
      }
    );
    return current;
  }
  function trackInteractionHandler(task) {
    pendingInteractionHandlers.add(task);
    void task.then(
      () => pendingInteractionHandlers.delete(task),
      () => pendingInteractionHandlers.delete(task)
    );
    return task;
  }
  async function persistInteractionEvent(sessionId, interactionId, event) {
    return enqueueInteractionTask(`${sessionId}:${interactionId}`, async () => {
      const previous = await db.getInteraction(interactionId);
      const next = applyInteractionEvent(previous, event);
      if (next && next !== previous) {
        const stored = await db.saveInteractionWithinBudget(next);
        if (!stored.stored) return { previous, next: previous, budgetRejected: true };
      }
      return { previous, next };
    });
  }
  async function applySessionEvent2(sessionId, event) {
    const next = await db.updateSession(sessionId, (current) => applySessionEvent(current, event));
    if (!next) throw new Error(`\u672A\u627E\u5230\u4F1A\u8BDD (SESSION_NOT_FOUND:${sessionId})`);
    return next;
  }
  var cdpCollector = new CdpEvidenceCollector(db, applySessionEvent2, (sessionId) => recordingCoordinator.isStopping(sessionId));
  async function reconcileSessionQuality(sessionId) {
    const [interactions, consoleEntries, networkEntries] = await Promise.all([
      db.getInteractions(sessionId),
      db.getConsole(sessionId),
      db.getNetwork(sessionId)
    ]);
    const included = interactions.filter((entry) => entry.status !== "cancelled");
    await applySessionEvent2(sessionId, {
      type: "quality-snapshot",
      counts: {
        interactionCount: included.length,
        confirmedInteractionCount: included.filter((entry) => entry.status === "confirmed").length,
        primaryScreenshotCount: included.filter((entry) => entry.screenshot.status === "captured" && entry.screenshot.source === "primary").length,
        fallbackScreenshotCount: included.filter((entry) => entry.screenshot.status === "captured" && entry.screenshot.source === "video-frame").length,
        unavailableScreenshotCount: included.filter((entry) => entry.screenshot.status === "unavailable").length,
        consoleEntryCount: consoleEntries.length,
        networkEntryCount: networkEntries.length
      }
    });
  }
  async function assertTargetTabIsActive(session) {
    const query = { active: true };
    if (typeof session.target.windowId === "number") query.windowId = session.target.windowId;
    const activeTabs = await chrome.tabs.query(query);
    if (!activeTabs.some((tab) => tab.id === session.target.tabId)) {
      throw new Error("TARGET_TAB_NOT_ACTIVE: \u5F53\u524D\u6FC0\u6D3B\u6807\u7B7E\u9875\u4E0D\u662F\u5F55\u5236\u76EE\u6807\uFF0C\u5DF2\u62D2\u7EDD\u4FDD\u5B58\u622A\u56FE");
    }
  }
  function issue(code, messageText, source, recoverable = true) {
    return { code, message: messageText, source, recoverable, occurredAt: Date.now() };
  }
  async function ensureOffscreen() {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    if (contexts.length) return;
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["USER_MEDIA", "BLOBS"],
      justification: "Record the selected tab and persist media chunks locally."
    });
  }
  async function injectContent(tabId) {
    if (!registeredContentScript) {
      try {
        await chrome.scripting.registerContentScripts([{
          id: "web-bug-recorder-content",
          js: ["content.js"],
          matches: ["http://*/*", "https://*/*"],
          allFrames: true,
          runAt: "document_start",
          persistAcrossSessions: false
        }]);
      } catch (error) {
        if (!String(error).includes("already exists")) registeredContentScript = false;
      }
      if (!registeredContentScript) {
        const registrations = await chrome.scripting.getRegisteredContentScripts({ ids: ["web-bug-recorder-content"] }).catch(() => []);
        registeredContentScript = registrations.length > 0;
      }
    }
    await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["content.js"] }).catch(() => void 0);
  }
  async function removeContentScript(tabId) {
    if (typeof tabId === "number") {
      await chrome.tabs.sendMessage(tabId, message("content/reset", {})).catch(() => void 0);
    }
    const registrations = await chrome.scripting.getRegisteredContentScripts({ ids: ["web-bug-recorder-content"] }).catch(() => []);
    if (registeredContentScript || registrations.length) {
      await chrome.scripting.unregisterContentScripts({ ids: ["web-bug-recorder-content"] }).catch(() => void 0);
    }
    registeredContentScript = false;
  }
  async function startSessionImpl(payload) {
    const previousCommand = await db.getCommand(payload.commandId);
    if (previousCommand) {
      if (previousCommand.kind !== "start") throw new Error(`\u6307\u4EE4\u7C7B\u578B\u51B2\u7A81 (COMMAND_KIND_CONFLICT:${payload.commandId})`);
      const previousSession = await db.getSession(previousCommand.sessionId);
      if (previousSession) return previousSession;
      throw new Error(`\u6307\u4EE4\u5BF9\u5E94\u4F1A\u8BDD\u4E0D\u5B58\u5728 (COMMAND_SESSION_MISSING:${payload.commandId})`);
    }
    const tab = await chrome.tabs.get(payload.tabId);
    const options = normalizeRecordingOptions(payload.options, await db.getStoragePolicy());
    const browserEpoch = await browserEpochPromise;
    const session = {
      id: crypto.randomUUID(),
      schemaVersion: 2,
      extensionVersion: EXTENSION_VERSION,
      status: "PREPARING",
      target: {
        tabId: payload.tabId,
        windowId: tab.windowId,
        initialUrl: sanitizeUrl(tab.url ?? "", options.privacyMode),
        initialTitle: sanitizeText(tab.title ?? "", options.privacyMode, 256)
      },
      options,
      timeline: { createdAtEpochMs: Date.now() },
      quality: { overall: "complete", interactionCount: 0, confirmedInteractionCount: 0, primaryScreenshotCount: 0, fallbackScreenshotCount: 0, unavailableScreenshotCount: 0, consoleEntryCount: 0, networkEntryCount: 0, issues: [] },
      nonce: crypto.randomUUID(),
      commandIds: { start: payload.commandId },
      browserEpoch,
      resumedFromSessionId: payload.resumedFromSessionId,
      storage: { usedBytes: 0 }
    };
    const claim = await db.claimSession(session);
    if (!claim.claimed) {
      if (claim.session.commandIds?.start === payload.commandId) return claim.session;
      throw new Error(`\u5DF2\u6709\u6D3B\u52A8\u4F1A\u8BDD\u5728\u5F55\u5236\u4E2D (SESSION_ALREADY_ACTIVE:${claim.session.id})`);
    }
    let mediaStarted = false;
    try {
      const streamId = !options.captureVideo ? void 0 : payload.streamId ? payload.streamId : await new Promise((resolve, reject) => chrome.tabCapture.getMediaStreamId({ targetTabId: payload.tabId }, (id) => id ? resolve(id) : reject(chrome.runtime.lastError ?? new Error("\u672A\u8FD4\u56DE\u5A92\u4F53\u6D41 ID")))).catch(() => void 0);
      await ensureOffscreen();
      await injectContent(payload.tabId);
      const debuggerIssue = options.captureConsole || options.captureNetwork ? await cdpCollector.attach(payload.tabId, session) : void 0;
      const issues = debuggerIssue ? [debuggerIssue] : [];
      if (streamId) {
        const mediaResponse = await chrome.runtime.sendMessage(message("offscreen/start-media", { streamId, sessionId: session.id, captureAudio: options.captureAudio, timesliceMs: options.mediaTimesliceMs }, session.id)).catch((error) => ({ ok: false, error: String(error) }));
        if (mediaResponse?.ok) mediaStarted = true;
        else issues.push(issue("MEDIA_RECORDER_FAILED", sanitizeText(mediaResponse?.error ?? "\u5A92\u4F53\u5F55\u5236\u542F\u52A8\u5931\u8D25", options.privacyMode), "media", false));
      } else if (options.captureVideo) {
        issues.push(issue("MEDIA_STREAM_ID_FAILED", "\u672A\u53D6\u5F97\u6807\u7B7E\u9875\u5A92\u4F53\u6D41\uFF0C\u5DF2\u8FDB\u5165\u964D\u7EA7\u5F55\u5236\u3002", "media", false));
      }
      const started = await applySessionEvent2(session.id, { type: "started", atEpochMs: Date.now(), issues });
      if (["RECORDING", "DEGRADED"].includes(started.status)) {
        await chrome.action.setBadgeText({ tabId: payload.tabId, text: "REC" }).catch(() => void 0);
        await chrome.action.setBadgeBackgroundColor({ tabId: payload.tabId, color: "#d92d20" }).catch(() => void 0);
        await chrome.action.setIcon({ tabId: payload.tabId, path: "icons/icon_recording.png" }).catch(() => void 0);
      } else if (mediaStarted) {
        await chrome.runtime.sendMessage(message("offscreen/stop-media", { sessionId: session.id }, session.id)).catch(() => void 0);
      }
      return started;
    } catch (error) {
      if (mediaStarted) await chrome.runtime.sendMessage(message("offscreen/stop-media", { sessionId: session.id }, session.id)).catch(() => void 0);
      const failure = issue("SESSION_START_FAILED", sanitizeText(String(error), options.privacyMode), "media", false);
      const failed = await applySessionEvent2(session.id, { type: "failed", issue: failure });
      await db.clearActive(session.id);
      await cdpCollector.detach(payload.tabId);
      await removeContentScript(payload.tabId);
      await chrome.action.setBadgeText({ tabId: payload.tabId, text: "" }).catch(() => void 0);
      return failed;
    }
  }
  function startSession(payload) {
    return recordingCoordinator.runLifecycle(() => startSessionImpl(payload));
  }
  async function continueInterruptedSession(sessionId, commandId) {
    const previous = await db.getSession(sessionId);
    if (!previous) throw new Error(`\u672A\u627E\u5230\u4E2D\u65AD\u4F1A\u8BDD (SESSION_NOT_FOUND:${sessionId})`);
    if (!previous.quality.issues.some((entry) => entry.code.startsWith("SESSION_") || entry.code === "MEDIA_CONTEXT_LOST")) {
      throw new Error("\u8BE5\u4F1A\u8BDD\u672A\u5904\u4E8E\u53EF\u7EE7\u7EED\u72B6\u6001");
    }
    const tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (!tab?.id) throw new Error("\u65E0\u6CD5\u8BFB\u53D6\u5F53\u524D\u6807\u7B7E\u9875\uFF0C\u65E0\u6CD5\u7EE7\u7EED\u5F55\u5236");
    return startSession({ tabId: tab.id, options: previous.options, commandId, resumedFromSessionId: previous.id });
  }
  async function performStopSession(session, commandId) {
    if (["PREVIEW_READY", "EXPORTED", "FAILED"].includes(session.status)) return session;
    const stopping = await applySessionEvent2(session.id, { type: "stop-requested", atEpochMs: Date.now(), commandId });
    if (commandId && stopping.commandIds?.stop && stopping.commandIds.stop !== commandId) return stopping;
    recordingCoordinator.beginStopping(session.id);
    const cleanupErrors = [];
    try {
      await cdpCollector.detach(session.target.tabId);
      await removeContentScript(session.target.tabId);
      const mediaResponse = await chrome.runtime.sendMessage(message("offscreen/stop-media", { sessionId: session.id }, session.id)).catch((error) => ({ ok: false, error: String(error) }));
      if (mediaResponse?.ok === false) cleanupErrors.push(`\u5A92\u4F53\u505C\u6B62\u5931\u8D25\uFF1A${mediaResponse.error ?? "\u672A\u77E5\u9519\u8BEF"}`);
      for (let round = 0; round < 3; round += 1) {
        const interactionResults = await Promise.allSettled([...pendingInteractionHandlers]);
        for (const result of interactionResults) if (result.status === "rejected") cleanupErrors.push(`\u4EA4\u4E92\u5199\u5165\u672A\u5B8C\u6210\uFF1A${String(result.reason)}`);
        if (!pendingInteractionHandlers.size) break;
      }
      cleanupErrors.push(...await cdpCollector.drain());
      await cdpCollector.finalizeNetworkBodies(stopping).catch((error) => cleanupErrors.push(`Network \u6B63\u6587\u6536\u5C3E\u5931\u8D25\uFF1A${String(error)}`));
      await reconcileSessionQuality(session.id).catch((error) => cleanupErrors.push(`\u8D28\u91CF\u6458\u8981\u91CD\u7B97\u5931\u8D25\uFF1A${String(error)}`));
    } finally {
      await cdpCollector.detach(session.target.tabId);
      await removeContentScript(session.target.tabId);
      await chrome.action.setBadgeText({ tabId: session.target.tabId, text: "" }).catch(() => void 0);
      await chrome.action.setIcon({ tabId: session.target.tabId, path: "icons/icon_idle.png" }).catch(() => void 0);
    }
    const cleanupIssue = cleanupErrors.length ? issue("SESSION_STOP_PARTIAL", sanitizeText(cleanupErrors.join("\uFF1B"), session.options.privacyMode), "storage") : void 0;
    try {
      const next = await db.updateSession(session.id, (current) => ({
        ...applySessionEvent(current, { type: "stop-completed", issue: cleanupIssue }),
        previewPending: true
      }));
      if (!next) throw new Error(`\u672A\u627E\u5230\u4F1A\u8BDD (SESSION_NOT_FOUND:${session.id})`);
      return await openPendingPreview(next);
    } finally {
      recordingCoordinator.finishStopping(session.id);
    }
  }
  async function stopSessionImpl(commandId) {
    let session;
    if (commandId) {
      const previousCommand = await db.getCommand(commandId);
      if (previousCommand) {
        if (previousCommand.kind !== "stop") throw new Error(`\u6307\u4EE4\u7C7B\u578B\u51B2\u7A81 (COMMAND_KIND_CONFLICT:${commandId})`);
        session = await db.getSession(previousCommand.sessionId);
        if (!session) throw new Error(`\u6307\u4EE4\u5BF9\u5E94\u4F1A\u8BDD\u4E0D\u5B58\u5728 (COMMAND_SESSION_MISSING:${commandId})`);
      }
    }
    if (!session) session = await db.getActiveSession();
    if (!session) return void 0;
    if (commandId && !await db.getCommand(commandId)) {
      const claimed = await db.claimCommand({ commandId, kind: "stop", sessionId: session.id, createdAtEpochMs: Date.now() });
      if (!claimed.claimed) {
        if (claimed.command.kind !== "stop") throw new Error(`\u6307\u4EE4\u7C7B\u578B\u51B2\u7A81 (COMMAND_KIND_CONFLICT:${commandId})`);
        session = await db.getSession(claimed.command.sessionId) ?? session;
      }
    }
    return recordingCoordinator.runStop(session.id, () => performStopSession(session, commandId));
  }
  function stopSession(commandId) {
    return recordingCoordinator.runLifecycle(() => stopSessionImpl(commandId));
  }
  async function handleInteraction(interaction, sender) {
    const session = await db.getActiveSession();
    if (!session || recordingCoordinator.isStopping(session.id) || !["PREPARING", "RECORDING", "DEGRADED"].includes(session.status) || session.target.tabId !== sender.tab?.id || session.nonce !== interaction.sessionId) return;
    const incoming = sanitizeInteractionRecord({
      ...interaction,
      sessionId: session.id,
      screenshot: session.options.captureScreenshots ? interaction.screenshot : { status: "disabled" }
    }, session.options.privacyMode);
    const event = incoming.status === "confirmed" ? { type: "confirmed", interaction: incoming } : { type: "candidate", interaction: incoming };
    const { previous, next, budgetRejected } = await persistInteractionEvent(session.id, incoming.id, event);
    if (budgetRejected) {
      await applySessionEvent2(session.id, { type: "capture-issue", issue: issue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A\u4EA4\u4E92\u8BC1\u636E\u3002", "storage") });
      return;
    }
    if (!next) return;
    const interactionDelta = {
      interactionCount: previous ? 0 : 1,
      confirmedInteractionCount: next.status === "confirmed" && previous?.status !== "confirmed" ? 1 : 0
    };
    if (interactionDelta.interactionCount || interactionDelta.confirmedInteractionCount) {
      await applySessionEvent2(session.id, { type: "quality-delta", delta: interactionDelta });
    }
    if (session.options.captureScreenshots && (event.type === "candidate" || event.type === "confirmed") && !previous) {
      try {
        const capture = chrome.tabs.captureVisibleTab;
        if ((sender.frameId ?? 0) !== 0) throw new Error("FRAME_GEOMETRY_UNAVAILABLE: iframe \u5750\u6807\u6682\u65E0\u6CD5\u53EF\u9760\u6620\u5C04\u5230\u9876\u5C42\u89C6\u53E3");
        await assertTargetTabIsActive(session);
        const dataUrl = await capture(session.target.windowId ?? chrome.windows.WINDOW_ID_CURRENT, { format: "png" });
        await assertTargetTabIsActive(session);
        const annotated = await chrome.runtime.sendMessage(message("offscreen/annotate-image", { dataUrl, clientX: next.coordinates.clientX, clientY: next.coordinates.clientY, viewportWidth: next.coordinates.viewport.width, viewportHeight: next.coordinates.viewport.height }, session.id));
        if (!annotated?.ok || typeof annotated.dataUrl !== "string") throw new Error(annotated?.error || "\u622A\u56FE\u6807\u8BB0\u5931\u8D25");
        const screenshotResult = await persistInteractionEvent(session.id, next.id, { type: "screenshot-captured", source: "primary", dataUrl: annotated.dataUrl });
        if (screenshotResult.budgetRejected) {
          await applySessionEvent2(session.id, { type: "capture-issue", issue: issue("SESSION_STORAGE_LIMIT_REACHED", "\u5DF2\u8FBE\u5230\u4F1A\u8BDD\u5B58\u50A8\u4E0A\u9650\uFF0C\u672A\u4FDD\u5B58\u66F4\u591A\u70B9\u51FB\u622A\u56FE\u3002", "storage") });
          return;
        }
        if (screenshotResult.previous?.status !== "cancelled" && screenshotResult.previous?.screenshot.status !== "captured") {
          await applySessionEvent2(session.id, { type: "quality-delta", delta: { primaryScreenshotCount: 1 } });
        }
      } catch (error) {
        const safeError = sanitizeText(String(error), session.options.privacyMode);
        const screenshotResult = await persistInteractionEvent(session.id, next.id, { type: "screenshot-unavailable", issue: safeError });
        if (screenshotResult.budgetRejected) return;
        if (screenshotResult.previous?.status !== "cancelled" && screenshotResult.previous?.screenshot.status !== "unavailable") {
          await applySessionEvent2(session.id, { type: "quality-delta", delta: { unavailableScreenshotCount: 1 } });
          await applySessionEvent2(session.id, { type: "capture-issue", issue: issue("VISIBLE_TAB_NOT_ACTIVE", safeError, "screenshot") });
        }
      }
    }
  }
  async function handleInteractionCancelled(interactionId, interaction, nonce, sender) {
    const session = await db.getActiveSession();
    if (!session || recordingCoordinator.isStopping(session.id) || !["PREPARING", "RECORDING", "DEGRADED"].includes(session.status) || session.target.tabId !== sender.tab?.id || session.nonce !== nonce) return;
    const cancelled = interaction ? sanitizeInteractionRecord({ ...interaction, sessionId: session.id, status: "cancelled" }, session.options.privacyMode) : void 0;
    const { previous, next } = await persistInteractionEvent(session.id, interactionId, { type: "cancelled", interaction: cancelled });
    if (!previous || next?.status !== "cancelled" || previous.status === "cancelled") return;
    const delta = {
      type: "quality-delta",
      delta: { interactionCount: -1 }
    };
    if (previous.screenshot.status === "captured") {
      if (previous.screenshot.source === "primary") delta.delta.primaryScreenshotCount = -1;
      else delta.delta.fallbackScreenshotCount = -1;
    } else if (previous.screenshot.status === "unavailable") {
      delta.delta.unavailableScreenshotCount = -1;
    }
    await applySessionEvent2(session.id, delta);
  }
  async function openPendingPreview(session) {
    if (!session.previewPending) return session;
    const previewUrl = chrome.runtime.getURL(`preview.html?sessionId=${encodeURIComponent(session.id)}`);
    const existing = await chrome.tabs.query({}).then(
      (tabs) => tabs.some((tab) => tab.url === previewUrl),
      () => false
    );
    const opened = existing || await chrome.tabs.create({ url: previewUrl }).then(() => true).catch(() => false);
    if (!opened) return session;
    return await db.updateSessionAndClearActive(session.id, (current) => ({ ...current, previewPending: false })) ?? { ...session, previewPending: false };
  }
  async function recoverInterruptedSession(session, code, messageText) {
    await reconcileSessionQuality(session.id).catch(() => void 0);
    const recovered = await db.updateSession(session.id, (current) => ({
      ...applySessionEvent(current, {
        type: "recover",
        atEpochMs: Date.now(),
        issue: issue(code, messageText, "storage")
      }),
      previewPending: true
    }));
    if (!recovered) return;
    await cdpCollector.detach(session.target.tabId);
    await removeContentScript(session.target.tabId);
    await chrome.action.setBadgeText({ tabId: session.target.tabId, text: "" }).catch(() => void 0);
    await chrome.action.setIcon({ tabId: session.target.tabId, path: "icons/icon_idle.png" }).catch(() => void 0);
    await openPendingPreview(recovered);
  }
  async function bootstrapRuntimeState() {
    await db.cleanupExpiredSessions().catch(() => void 0);
    const browserEpoch = await browserEpochPromise;
    const session = await db.getActiveSession();
    if (!session) return;
    if (!["PREPARING", "RECORDING", "DEGRADED", "STOPPING"].includes(session.status)) {
      if (session.previewPending) await openPendingPreview(session);
      else await db.clearActive(session.id);
      return;
    }
    if (!session.browserEpoch || session.browserEpoch !== browserEpoch) {
      await recoverInterruptedSession(session, "SESSION_INTERRUPTED_BY_BROWSER_RESTART", "\u6D4F\u89C8\u5668\u91CD\u542F\u4E2D\u65AD\u4E86\u5F55\u5236\uFF0C\u5DF2\u4FDD\u7559\u73B0\u6709\u8BC1\u636E\u3002");
      return;
    }
    if (session.status === "STOPPING") {
      await stopSession(session.commandIds?.stop);
      return;
    }
    if (session.status === "PREPARING") {
      await recoverInterruptedSession(session, "SESSION_START_INTERRUPTED", "\u5F55\u5236\u542F\u52A8\u8FC7\u7A0B\u88AB\u4E2D\u65AD\uFF0C\u5DF2\u4FDD\u7559\u542F\u52A8\u524D\u8BC1\u636E\u3002");
      return;
    }
    const targetExists = await chrome.tabs.get(session.target.tabId).then(() => true).catch(() => false);
    if (!targetExists) {
      await stopSession(`system:missing-tab:${session.id}`);
      return;
    }
    const registrations = await chrome.scripting.getRegisteredContentScripts({ ids: ["web-bug-recorder-content"] }).catch(() => []);
    registeredContentScript = registrations.length > 0;
    if (!registeredContentScript) await injectContent(session.target.tabId);
    const mediaWasExpected = session.options.captureVideo && !session.quality.issues.some((entry) => entry.code === "MEDIA_STREAM_ID_FAILED" || entry.code === "MEDIA_RECORDER_FAILED");
    if (mediaWasExpected) {
      const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] }).catch(() => []);
      const mediaStatus = contexts.length ? await chrome.runtime.sendMessage(message("offscreen/status", { sessionId: session.id }, session.id)).catch(() => void 0) : void 0;
      if (!mediaStatus?.active) {
        await applySessionEvent2(session.id, { type: "capture-issue", issue: issue("MEDIA_CONTEXT_LOST", "\u540E\u53F0\u6062\u590D\u540E\u672A\u627E\u5230\u6D3B\u52A8\u7684\u5A92\u4F53\u5F55\u5236\u4E0A\u4E0B\u6587\u3002", "media", false) });
      }
    }
    if (session.options.captureConsole || session.options.captureNetwork) {
      const targets = await chrome.debugger.getTargets().catch(() => []);
      if (targets.some((target) => target.tabId === session.target.tabId && target.attached)) {
        cdpCollector.markAttached(session.target.tabId);
      } else {
        const debuggerIssue = await cdpCollector.attach(session.target.tabId, session);
        if (debuggerIssue) await applySessionEvent2(session.id, { type: "capture-issue", issue: debuggerIssue });
      }
    }
    await chrome.action.setBadgeText({ tabId: session.target.tabId, text: "REC" }).catch(() => void 0);
    await chrome.action.setBadgeBackgroundColor({ tabId: session.target.tabId, color: "#d92d20" }).catch(() => void 0);
    await chrome.action.setIcon({ tabId: session.target.tabId, path: "icons/icon_recording.png" }).catch(() => void 0);
  }
  var bootstrapPromise = bootstrapRuntimeState().catch(() => void 0);
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    if (!isEnvelope(raw)) return;
    const incoming = raw;
    if (incoming.type === "offscreen/start-media" || incoming.type === "offscreen/stop-media" || incoming.type === "offscreen/status" || incoming.type === "offscreen/annotate-image") return;
    void (async () => {
      try {
        if (incoming.type === "offscreen/media-state") {
          const session = await db.getSession(incoming.payload.sessionId);
          if (session && incoming.payload.state === "error" && sender.url === chrome.runtime.getURL("offscreen.html")) {
            await applySessionEvent2(session.id, { type: "capture-issue", issue: issue("MEDIA_RECORDER_FAILED", sanitizeText(incoming.payload.error ?? "\u5A92\u4F53\u5F55\u5236\u5931\u8D25", session.options.privacyMode), "media", false) });
          }
          sendResponse({ ok: true });
          return;
        }
        await bootstrapPromise;
        switch (incoming.type) {
          case "session/start":
            sendResponse({ ok: true, session: await startSession(incoming.payload) });
            return;
          case "session/stop":
            sendResponse({ ok: true, session: await stopSession(incoming.payload.commandId) });
            return;
          case "session/status":
            sendResponse({ ok: true, session: await db.getActiveSession() });
            return;
          case "session/list":
            sendResponse({ ok: true, sessions: await db.listSessionOverviews(incoming.payload.query) });
            return;
          case "session/delete": {
            const active = await db.getActiveSession();
            if (active?.id === incoming.payload.sessionId) throw new Error("\u4E0D\u80FD\u5220\u9664\u6B63\u5728\u5F55\u5236\u7684\u4F1A\u8BDD");
            sendResponse({ ok: true, deleted: await db.deleteSession(incoming.payload.sessionId) });
            return;
          }
          case "session/resume":
            sendResponse({ ok: true, session: await continueInterruptedSession(incoming.payload.sessionId, incoming.payload.commandId) });
            return;
          case "storage/get":
            sendResponse({ ok: true, storage: await db.getStorageOverview() });
            return;
          case "storage/update":
            sendResponse({ ok: true, policy: await db.saveStoragePolicy(incoming.payload.policy) });
            return;
          case "storage/cleanup":
            sendResponse({ ok: true, deletedSessionIds: await db.cleanupExpiredSessions() });
            return;
          case "session/open-preview":
            await chrome.tabs.create({ url: chrome.runtime.getURL(`preview.html?sessionId=${incoming.payload.sessionId}`) });
            sendResponse({ ok: true });
            return;
          case "content/hello": {
            const session = await db.getActiveSession();
            const allowed = Boolean(session && ["PREPARING", "RECORDING", "DEGRADED"].includes(session.status) && session.target.tabId === sender.tab?.id);
            sendResponse({ ok: true, active: allowed, sessionId: allowed ? session?.id : void 0, nonce: allowed ? session?.nonce : void 0, startedAtEpochMs: allowed ? session?.timeline.startedAtEpochMs : void 0, privacyMode: allowed ? session?.options.privacyMode : void 0 });
            return;
          }
          case "interaction/candidate":
          case "interaction/confirmed":
            await trackInteractionHandler(handleInteraction(incoming.payload.interaction, sender));
            sendResponse({ ok: true });
            return;
          case "interaction/cancelled":
            await trackInteractionHandler(handleInteractionCancelled(incoming.payload.interactionId, incoming.payload.interaction, incoming.sessionId, sender));
            sendResponse({ ok: true });
            return;
          case "offscreen/media-chunk": {
            const result = await db.saveMediaChunkWithinBudget({ id: `${incoming.payload.sessionId}:${incoming.payload.sequence}`, ...incoming.payload });
            sendResponse({ ok: result.stored, error: result.stored ? void 0 : "SESSION_STORAGE_LIMIT_REACHED" });
            return;
          }
          default:
            sendResponse({ ok: false, error: "UNSUPPORTED_MESSAGE" });
        }
      } catch (error) {
        sendResponse({ ok: false, error: String(error) });
      }
    })();
    return true;
  });
  chrome.debugger.onEvent.addListener((source, method, params) => {
    cdpCollector.handleEvent(source, method, params);
  });
  chrome.debugger.onDetach.addListener((source, reason) => {
    void bootstrapPromise.then(() => cdpCollector.handleDetach(source, reason));
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void (async () => {
      await bootstrapPromise;
      const session = await db.getActiveSession();
      if (session?.target.tabId === tabId) await stopSession(`system:tab-removed:${session.id}`);
    })();
  });
  chrome.runtime.onStartup.addListener(() => {
    void bootstrapPromise;
  });
  chrome.alarms.create("bug-lens-storage-cleanup", { periodInMinutes: 24 * 60 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "bug-lens-storage-cleanup") void db.cleanupExpiredSessions();
  });
})();
