"use strict";
(() => {
  // src/storage/db.ts
  var DB_NAME = "web-bug-recorder";
  var DB_VERSION = 4;
  var openPromise;
  function openDb() {
    if (openPromise) return openPromise;
    openPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        const transaction = request.transaction;
        if (!transaction) throw new Error("IndexedDB migration transaction unavailable");
        const ensureStore = (name, keyPath, indexes = []) => {
          const store = database.objectStoreNames.contains(name) ? transaction.objectStore(name) : database.createObjectStore(name, { keyPath });
          for (const index of indexes) {
            if (!store.indexNames.contains(index.name)) store.createIndex(index.name, index.keyPath);
          }
        };
        ensureStore("control", "key");
        ensureStore("sessions", "id", [{ name: "status", keyPath: "status" }]);
        ensureStore("interactions", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("consoleEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("networkEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("mediaChunks", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("exportSelections", "sessionId");
        ensureStore("exportArtifacts", "sessionId");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return openPromise;
  }
  async function put(storeName, value) {
    const db2 = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db2.transaction(storeName, "readwrite");
      tx.objectStore(storeName).put(value);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async function get(storeName, key) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function list(storeName, indexName, key) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).index(indexName).getAll(key);
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }
  var db = {
    getSession: (id) => get("sessions", id),
    saveSession: (session) => put("sessions", session),
    getActiveSession: async () => {
      const active = await get("control", "active-session");
      return active?.sessionId ? get("sessions", active.sessionId) : void 0;
    },
    claimSession: async (session) => {
      const dbInstance = await openDb();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction(["control", "sessions"], "readwrite");
        const control = tx.objectStore("control");
        const sessions = tx.objectStore("sessions");
        const currentReq = control.get("active-session");
        currentReq.onsuccess = () => {
          const current = currentReq.result;
          if (current?.sessionId) {
            const existingReq = sessions.get(current.sessionId);
            existingReq.onsuccess = () => resolve({ session: existingReq.result, claimed: false });
            existingReq.onerror = () => reject(existingReq.error);
            return;
          }
          sessions.put(session);
          control.put({ key: "active-session", sessionId: session.id });
          resolve({ session, claimed: true });
        };
        tx.onerror = () => reject(tx.error);
      });
    },
    clearActive: async (sessionId) => {
      const current = await get("control", "active-session");
      if (current?.sessionId === sessionId) {
        const dbInstance = await openDb();
        await new Promise((resolve, reject) => {
          const tx = dbInstance.transaction("control", "readwrite");
          tx.objectStore("control").delete("active-session");
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
        });
      }
    },
    saveInteraction: (record) => put("interactions", record),
    getInteractions: (sessionId) => list("interactions", "sessionId", sessionId),
    saveConsole: (entry) => put("consoleEntries", entry),
    getConsole: (sessionId) => list("consoleEntries", "sessionId", sessionId),
    saveNetwork: (entry) => put("networkEntries", entry),
    getNetwork: (sessionId) => list("networkEntries", "sessionId", sessionId),
    saveMediaChunk: (chunk) => put("mediaChunks", chunk),
    getMediaChunks: (sessionId) => list("mediaChunks", "sessionId", sessionId),
    getExportSelection: (sessionId) => get("exportSelections", sessionId),
    saveExportSelection: (selection) => put("exportSelections", selection),
    getExportArtifact: (sessionId) => get("exportArtifacts", sessionId),
    saveExportArtifact: (artifact) => put("exportArtifacts", artifact)
  };

  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }
  function isEnvelope(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    return candidate.protocolVersion === PROTOCOL_VERSION && typeof candidate.type === "string" && typeof candidate.messageId === "string";
  }

  // src/entrypoints/background/index.ts
  var EXTENSION_VERSION = "0.1.0";
  var registeredContentScript = false;
  var debuggerTabs = /* @__PURE__ */ new Set();
  var pendingBodyCaptures = /* @__PURE__ */ new Set();
  var networkEventQueues = /* @__PURE__ */ new Map();
  function normalizeHeaders(headers, privacyMode) {
    if (!headers) return void 0;
    const sensitiveHeader = /^(authorization|proxy-authorization|cookie|set-cookie)$/i;
    return Object.fromEntries(Object.entries(headers).map(([key, value]) => [key, privacyMode === "safe" && sensitiveHeader.test(key) ? `[REDACTED:${key}]` : String(value)]));
  }
  function redactResponseText(body, mimeType, privacyMode) {
    if (privacyMode === "raw") return body;
    const sensitiveKey = /^(password|passwd|token|accessToken|refreshToken|authorization|secret|cookie|set-cookie|cardNumber)$/i;
    if (mimeType?.includes("json") || /^[\s]*[\[{]/.test(body)) {
      try {
        const redactValue = (value, depth = 0) => {
          if (depth > 30) return "[REDACTED:depth-limit]";
          if (Array.isArray(value)) return value.map((item) => redactValue(item, depth + 1));
          if (value && typeof value === "object") {
            const result = {};
            for (const [key, child] of Object.entries(value)) {
              if (["__proto__", "prototype", "constructor"].includes(key)) continue;
              result[key] = sensitiveKey.test(key) ? `[REDACTED:${key}]` : redactValue(child, depth + 1);
            }
            return result;
          }
          return value;
        };
        return JSON.stringify(redactValue(JSON.parse(body)));
      } catch {
      }
    }
    return body.replace(/Bearer\s+[A-Za-z0-9._~+/=-]+/gi, "Bearer [REDACTED]").replace(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g, "[REDACTED:jwt]");
  }
  function withTimeout(promise, timeoutMs, messageText) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(messageText)), timeoutMs);
      promise.then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (error) => {
          clearTimeout(timer);
          reject(error);
        }
      );
    });
  }
  async function captureResponseBody(source, session, requestId) {
    const id = `${session.id}:${requestId}`;
    const current = (await db.getNetwork(session.id)).find((entry) => entry.id === id);
    if (!current) return;
    if (current.method === "HEAD" || current.status === 204 || current.status === 304) {
      await db.saveNetwork({ ...current, response: { ...current.response, bodyStatus: "not-present" } });
      return;
    }
    try {
      const command = chrome.debugger.sendCommand(source, "Network.getResponseBody", { requestId });
      const result = await withTimeout(command, 3e3, "RESPONSE_BODY_TIMEOUT: \u54CD\u5E94\u6B63\u6587\u8BFB\u53D6\u8D85\u8FC7 3 \u79D2");
      const rawBody = result.body ?? "";
      const base64Encoded = Boolean(result.base64Encoded);
      const body = base64Encoded ? rawBody : redactResponseText(rawBody, current.response?.mimeType, session.options.privacyMode);
      const byteLength = base64Encoded ? Math.max(0, Math.floor(rawBody.length * 3 / 4) - (rawBody.endsWith("==") ? 2 : rawBody.endsWith("=") ? 1 : 0)) : new TextEncoder().encode(body).byteLength;
      await db.saveNetwork({ ...current, response: { ...current.response, bodyStatus: "captured", body, base64Encoded, byteLength } });
    } catch (error) {
      await db.saveNetwork({ ...current, response: { ...current.response, bodyStatus: "unavailable", error: String(error) } });
    }
  }
  async function finalizeNetworkBodies(session) {
    for (let round = 0; round < 3 && pendingBodyCaptures.size; round += 1) {
      await Promise.allSettled([...pendingBodyCaptures]);
    }
    const pending = (await db.getNetwork(session.id)).filter((entry) => entry.response?.bodyStatus === "pending");
    let cursor = 0;
    const deadline = Date.now() + 5e3;
    const workers = Array.from({ length: Math.min(4, pending.length) }, async () => {
      while (cursor < pending.length && Date.now() < deadline) {
        const entry = pending[cursor++];
        const requestId = entry.id.startsWith(`${session.id}:`) ? entry.id.slice(session.id.length + 1) : "";
        if (requestId) await captureResponseBody({ tabId: session.target.tabId }, session, requestId);
      }
    });
    await Promise.allSettled(workers);
    const unresolved = (await db.getNetwork(session.id)).filter((entry) => entry.response?.bodyStatus === "pending");
    await Promise.all(unresolved.map((entry) => db.saveNetwork({
      ...entry,
      response: {
        ...entry.response,
        bodyStatus: "unavailable",
        error: "RESPONSE_BODY_INCOMPLETE: \u5F55\u5236\u7ED3\u675F\u524D\u672A\u6536\u5230\u5B8C\u6574\u54CD\u5E94\u6216\u6D4F\u89C8\u5668\u672A\u63D0\u4F9B\u6B63\u6587"
      }
    })));
  }
  function trackBodyCapture(task) {
    pendingBodyCaptures.add(task);
    void task.then(
      () => pendingBodyCaptures.delete(task),
      () => pendingBodyCaptures.delete(task)
    );
  }
  function enqueueNetworkTask(key, work) {
    const previous = networkEventQueues.get(key) ?? Promise.resolve();
    const current = previous.catch(() => void 0).then(work);
    networkEventQueues.set(key, current);
    void current.then(
      () => {
        if (networkEventQueues.get(key) === current) networkEventQueues.delete(key);
      },
      () => {
        if (networkEventQueues.get(key) === current) networkEventQueues.delete(key);
      }
    );
    return current;
  }
  function issue(code, messageText, source, recoverable = true) {
    return { code, message: messageText, source, recoverable, occurredAt: Date.now() };
  }
  async function ensureOffscreen() {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    if (contexts.length) return;
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["USER_MEDIA", "BLOBS"],
      justification: "Record the selected tab and persist media chunks locally."
    });
  }
  async function injectContent(tabId) {
    if (!registeredContentScript) {
      try {
        await chrome.scripting.registerContentScripts([{
          id: "web-bug-recorder-content",
          js: ["content.js"],
          matches: ["http://*/*", "https://*/*"],
          allFrames: true,
          runAt: "document_start",
          persistAcrossSessions: false
        }]);
      } catch (error) {
        if (!String(error).includes("already exists")) registeredContentScript = false;
      }
      if (!registeredContentScript) {
        const registrations = await chrome.scripting.getRegisteredContentScripts({ ids: ["web-bug-recorder-content"] }).catch(() => []);
        registeredContentScript = registrations.length > 0;
      }
    }
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] }).catch(() => void 0);
  }
  async function removeContentScript() {
    if (!registeredContentScript) return;
    await chrome.scripting.unregisterContentScripts({ ids: ["web-bug-recorder-content"] }).catch(() => void 0);
    registeredContentScript = false;
  }
  async function attachDebugger(tabId, session) {
    try {
      await chrome.debugger.attach({ tabId }, "1.3");
      debuggerTabs.add(tabId);
      await chrome.debugger.sendCommand({ tabId }, "Runtime.enable");
      await chrome.debugger.sendCommand({ tabId }, "Network.enable", { maxTotalBufferSize: 50 * 1024 * 1024, maxResourceBufferSize: 10 * 1024 * 1024, maxPostDataSize: 1024 * 1024 }).catch(() => void 0);
      await chrome.debugger.sendCommand({ tabId }, "Log.enable").catch(() => void 0);
      return void 0;
    } catch (error) {
      return issue("DEBUGGER_ATTACH_FAILED", String(error), "debugger");
    }
  }
  async function detachDebugger(tabId) {
    if (!debuggerTabs.has(tabId)) return;
    debuggerTabs.delete(tabId);
    await chrome.debugger.detach({ tabId }).catch(() => void 0);
  }
  async function updateSession(session, patch) {
    const next = { ...session, ...patch, quality: { ...session.quality, ...patch.quality ?? {} } };
    await db.saveSession(next);
    return next;
  }
  async function startSession(payload) {
    const streamIdPromise = payload.streamId ? Promise.resolve(payload.streamId) : new Promise((resolve, reject) => chrome.tabCapture.getMediaStreamId({ targetTabId: payload.tabId }, (id) => id ? resolve(id) : reject(chrome.runtime.lastError ?? new Error("\u672A\u8FD4\u56DE\u5A92\u4F53\u6D41 ID"))));
    const tab = await chrome.tabs.get(payload.tabId);
    const session = {
      id: crypto.randomUUID(),
      schemaVersion: 1,
      extensionVersion: EXTENSION_VERSION,
      status: "PREPARING",
      target: { tabId: payload.tabId, windowId: tab.windowId, initialUrl: tab.url ?? "", initialTitle: tab.title ?? "" },
      options: payload.options,
      timeline: { createdAtEpochMs: Date.now() },
      quality: { overall: "complete", interactionCount: 0, confirmedInteractionCount: 0, primaryScreenshotCount: 0, fallbackScreenshotCount: 0, unavailableScreenshotCount: 0, consoleEntryCount: 0, networkEntryCount: 0, issues: [] },
      nonce: crypto.randomUUID()
    };
    const claim = await db.claimSession(session);
    if (!claim.claimed) return claim.session;
    try {
      const streamId = await streamIdPromise.catch(() => void 0);
      await ensureOffscreen();
      await injectContent(payload.tabId);
      const debuggerIssue = await attachDebugger(payload.tabId, session);
      if (debuggerIssue) session.quality.issues.push(debuggerIssue);
      if (streamId) {
        await chrome.runtime.sendMessage(message("offscreen/start-media", { streamId, sessionId: session.id, captureAudio: payload.options.captureAudio, timesliceMs: payload.options.mediaTimesliceMs }, session.id));
      } else {
        session.quality.issues.push(issue("MEDIA_STREAM_ID_FAILED", "\u672A\u53D6\u5F97\u6807\u7B7E\u9875\u5A92\u4F53\u6D41\uFF0C\u5DF2\u8FDB\u5165\u964D\u7EA7\u5F55\u5236\u3002", "media", false));
      }
      const started = await updateSession(session, { status: debuggerIssue || !streamId ? "DEGRADED" : "RECORDING", timeline: { ...session.timeline, startedAtEpochMs: Date.now() } });
      await chrome.action.setBadgeText({ tabId: payload.tabId, text: "REC" });
      await chrome.action.setBadgeBackgroundColor({ tabId: payload.tabId, color: "#d92d20" });
      await chrome.action.setIcon({
        tabId: payload.tabId,
        path: "icons/icon_recording.png"
      }).catch(() => void 0);
      return started;
    } catch (error) {
      const failed = await updateSession(session, { status: "FAILED", error: issue("SESSION_START_FAILED", String(error), "media", false), quality: { ...session.quality, overall: "failed" } });
      await db.clearActive(session.id);
      await detachDebugger(payload.tabId);
      return failed;
    }
  }
  async function stopSession() {
    const session = await db.getActiveSession();
    if (!session) return void 0;
    if (["STOPPING", "PREVIEW_READY", "EXPORTED"].includes(session.status)) return session;
    const stopping = await updateSession(session, { status: "STOPPING", timeline: { ...session.timeline, stoppedAtEpochMs: Date.now() } });
    await chrome.runtime.sendMessage(message("offscreen/stop-media", { sessionId: session.id }, session.id)).catch(() => void 0);
    await finalizeNetworkBodies(stopping);
    await detachDebugger(session.target.tabId);
    await removeContentScript();
    await chrome.action.setBadgeText({ tabId: session.target.tabId, text: "" });
    await chrome.action.setIcon({
      tabId: session.target.tabId,
      path: "icons/icon_idle.png"
    }).catch(() => void 0);
    const stoppedAt = stopping.timeline.stoppedAtEpochMs ?? Date.now();
    const next = await updateSession(stopping, { status: "PREVIEW_READY", timeline: { ...stopping.timeline, durationMs: stoppedAt - (stopping.timeline.startedAtEpochMs ?? stopping.timeline.createdAtEpochMs) } });
    await db.clearActive(session.id);
    await chrome.tabs.create({ url: chrome.runtime.getURL(`preview.html?sessionId=${encodeURIComponent(session.id)}`) });
    return next;
  }
  async function handleInteraction(interaction, sender) {
    const session = await db.getActiveSession();
    if (!session || session.target.tabId !== sender.tab?.id || session.nonce !== interaction.sessionId) return;
    const existing = await db.getInteractions(session.id);
    const previous = existing.find((item) => item.id === interaction.id);
    const candidate = { ...interaction, sessionId: session.id, screenshot: interaction.status === "confirmed" && previous ? previous.screenshot : interaction.screenshot };
    await db.saveInteraction(candidate);
    if (!previous) session.quality.interactionCount += 1;
    if (candidate.status === "confirmed" && previous?.status !== "confirmed") session.quality.confirmedInteractionCount += 1;
    await db.saveSession(session);
    if (candidate.status === "candidate") {
      try {
        const capture = chrome.tabs.captureVisibleTab;
        if ((sender.frameId ?? 0) !== 0) throw new Error("FRAME_GEOMETRY_UNAVAILABLE: iframe \u5750\u6807\u6682\u65E0\u6CD5\u53EF\u9760\u6620\u5C04\u5230\u9876\u5C42\u89C6\u53E3");
        const dataUrl = await capture(session.target.windowId ?? chrome.windows.WINDOW_ID_CURRENT, { format: "png" });
        const annotated = await chrome.runtime.sendMessage(message("offscreen/annotate-image", { dataUrl, clientX: candidate.coordinates.clientX, clientY: candidate.coordinates.clientY, viewportWidth: candidate.coordinates.viewport.width, viewportHeight: candidate.coordinates.viewport.height }, session.id));
        if (!annotated?.ok || typeof annotated.dataUrl !== "string") throw new Error(annotated?.error || "\u622A\u56FE\u6807\u8BB0\u5931\u8D25");
        const confirmed = { ...candidate, screenshot: { status: "captured", source: "primary", dataUrl: annotated.dataUrl } };
        await db.saveInteraction(confirmed);
        session.quality.primaryScreenshotCount += 1;
        await db.saveSession(session);
      } catch (error) {
        const unavailable = { ...candidate, screenshot: { status: "unavailable", issue: String(error) } };
        await db.saveInteraction(unavailable);
        session.quality.unavailableScreenshotCount += 1;
        session.quality.issues.push(issue("VISIBLE_TAB_NOT_ACTIVE", String(error), "screenshot"));
        session.quality.overall = "partial";
        await db.saveSession(session);
      }
    }
  }
  chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    if (!isEnvelope(raw)) return;
    const incoming = raw;
    if (incoming.type === "offscreen/start-media" || incoming.type === "offscreen/stop-media" || incoming.type === "offscreen/annotate-image") return;
    void (async () => {
      try {
        switch (incoming.type) {
          case "session/start":
            sendResponse({ ok: true, session: await startSession(incoming.payload) });
            return;
          case "session/stop":
            sendResponse({ ok: true, session: await stopSession() });
            return;
          case "session/status":
            sendResponse({ ok: true, session: await db.getActiveSession() });
            return;
          case "session/open-preview":
            await chrome.tabs.create({ url: chrome.runtime.getURL(`preview.html?sessionId=${incoming.payload.sessionId}`) });
            sendResponse({ ok: true });
            return;
          case "content/hello": {
            const session = await db.getActiveSession();
            const allowed = Boolean(session && session.target.tabId === sender.tab?.id);
            sendResponse({ ok: true, active: allowed, sessionId: allowed ? session?.id : void 0, nonce: allowed ? session?.nonce : void 0, startedAtEpochMs: allowed ? session?.timeline.startedAtEpochMs : void 0 });
            return;
          }
          case "interaction/candidate":
          case "interaction/confirmed":
            await handleInteraction(incoming.payload.interaction, sender);
            sendResponse({ ok: true });
            return;
          case "interaction/cancelled":
            sendResponse({ ok: true });
            return;
          case "offscreen/media-chunk":
            await db.saveMediaChunk({ id: `${incoming.payload.sessionId}:${incoming.payload.sequence}`, ...incoming.payload });
            sendResponse({ ok: true });
            return;
          case "offscreen/media-state": {
            const session = await db.getSession(incoming.payload.sessionId);
            if (session && incoming.payload.state === "error") await updateSession(session, { status: "DEGRADED", quality: { ...session.quality, overall: "partial", issues: [...session.quality.issues, issue("MEDIA_RECORDER_FAILED", incoming.payload.error ?? "\u5A92\u4F53\u5F55\u5236\u5931\u8D25", "media", false)] } });
            sendResponse({ ok: true });
            return;
          }
          default:
            sendResponse({ ok: false, error: "UNSUPPORTED_MESSAGE" });
        }
      } catch (error) {
        sendResponse({ ok: false, error: String(error) });
      }
    })();
    return true;
  });
  chrome.debugger.onEvent.addListener((source, method, params) => {
    const tabId = source.tabId;
    if (typeof tabId !== "number") return;
    void (async () => {
      const session = await db.getActiveSession();
      if (!session || session.target.tabId !== tabId) return;
      if (method === "Runtime.consoleAPICalled") {
        const p = params;
        await db.saveConsole({ id: crypto.randomUUID(), sessionId: session.id, createdAt: p.timestamp ?? Date.now(), level: p.type ?? "log", text: (p.args ?? []).map((arg) => typeof arg.value === "string" ? arg.value : arg.description ?? String(arg.value ?? "")).join(" ") });
        session.quality.consoleEntryCount += 1;
        await db.saveSession(session);
      } else if (method === "Runtime.exceptionThrown") {
        const p = params;
        const details = p.exceptionDetails;
        await db.saveConsole({ id: crypto.randomUUID(), sessionId: session.id, createdAt: p.timestamp ?? Date.now(), level: "error", text: details?.exception?.description ?? details?.text ?? "\u672A\u6355\u83B7\u5F02\u5E38", source: details?.url });
        session.quality.consoleEntryCount += 1;
        await db.saveSession(session);
      } else if (method === "Log.entryAdded") {
        const p = params;
        if (!p.entry) return;
        await db.saveConsole({ id: crypto.randomUUID(), sessionId: session.id, createdAt: p.entry.timestamp ?? Date.now(), level: p.entry.level ?? "info", text: p.entry.text ?? "", source: p.entry.url });
        session.quality.consoleEntryCount += 1;
        await db.saveSession(session);
      } else if (method === "Network.requestWillBeSent") {
        const p = params;
        if (!p.request?.url) return;
        const requestId = p.requestId ?? crypto.randomUUID();
        await enqueueNetworkTask(`${tabId}:${requestId}`, async () => {
          await db.saveNetwork({ id: `${session.id}:${requestId}`, sessionId: session.id, createdAt: (p.timestamp ?? 0) * 1e3 || Date.now(), url: p.request.url, method: p.request.method ?? "GET", type: p.type });
          session.quality.networkEntryCount += 1;
          await db.saveSession(session);
        });
      } else if (method === "Network.responseReceived") {
        const p = params;
        if (!p.requestId) return;
        const id = `${session.id}:${p.requestId ?? ""}`;
        await enqueueNetworkTask(`${tabId}:${p.requestId}`, async () => {
          const current = (await db.getNetwork(session.id)).find((entry) => entry.id === id);
          if (current) await db.saveNetwork({ ...current, status: p.response?.status, response: { mimeType: p.response?.mimeType, headers: normalizeHeaders(p.response?.headers, session.options.privacyMode), bodyStatus: "pending" } });
        });
      } else if (method === "Network.loadingFinished") {
        const p = params;
        if (p.requestId) trackBodyCapture(enqueueNetworkTask(`${tabId}:${p.requestId}`, () => captureResponseBody(source, session, p.requestId)));
      } else if (method === "Network.loadingFailed") {
        const p = params;
        if (!p.requestId) return;
        const id = `${session.id}:${p.requestId ?? ""}`;
        await enqueueNetworkTask(`${tabId}:${p.requestId}`, async () => {
          const current = (await db.getNetwork(session.id)).find((entry) => entry.id === id);
          if (current) await db.saveNetwork({ ...current, error: p.errorText ?? "\u8BF7\u6C42\u5931\u8D25", response: { ...current.response, bodyStatus: "unavailable", error: p.errorText ?? "\u8BF7\u6C42\u5931\u8D25" } });
        });
      }
    })();
  });
  chrome.debugger.onDetach.addListener((source, reason) => {
    if (typeof source.tabId !== "number" || reason === "target_closed") return;
    void (async () => {
      const session = await db.getActiveSession();
      if (!session || session.target.tabId !== source.tabId) return;
      await updateSession(session, { status: session.status === "RECORDING" ? "DEGRADED" : session.status, quality: { ...session.quality, overall: "partial", issues: [...session.quality.issues, issue("DEBUGGER_DETACHED_BY_DEVTOOLS", reason, "debugger")] } });
    })();
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void (async () => {
      const session = await db.getActiveSession();
      if (session?.target.tabId === tabId) await stopSession();
    })();
  });
  chrome.runtime.onStartup.addListener(() => {
    void db.getActiveSession();
  });
})();
