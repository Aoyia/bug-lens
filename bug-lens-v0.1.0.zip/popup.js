"use strict";
(() => {
  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }

  // src/entrypoints/popup/index.ts
  var $ = (selector) => document.querySelector(selector);
  var titleNode = $("#title");
  var urlNode = $("#url");
  var statusNode = $("#status");
  var dotNode = $("#dot");
  var timerNode = $("#timer");
  var errorNode = $("#error");
  var startButton = $("#start");
  var stopButton = $("#stop");
  var previewButton = $("#preview");
  var tab;
  var session;
  var timer;
  function showError(error) {
    errorNode.style.display = "block";
    errorNode.textContent = String(error);
  }
  function hideError() {
    errorNode.style.display = "none";
    errorNode.textContent = "";
  }
  function setState(next) {
    session = next;
    const active = Boolean(next && ["PREPARING", "RECORDING", "DEGRADED", "STOPPING"].includes(next.status));
    const ready = Boolean(next && ["PREVIEW_READY", "EXPORTED"].includes(next.status));
    statusNode.textContent = active ? next.status === "PREPARING" ? "\u6B63\u5728\u542F\u52A8\u5F55\u5236\u2026" : next.status === "DEGRADED" ? "\u5F55\u5236\u4E2D\uFF08\u964D\u7EA7\uFF09" : "\u5F55\u5236\u4E2D" : ready ? "\u5F55\u5236\u5DF2\u5B8C\u6210" : "\u672A\u5F55\u5236";
    dotNode.classList.toggle("rec", active);
    startButton.hidden = active || ready;
    stopButton.hidden = !active;
    stopButton.disabled = next?.status === "STOPPING";
    previewButton.hidden = !ready;
    if (ready && next) {
      previewButton.onclick = () => void chrome.runtime.sendMessage(message("session/open-preview", { sessionId: next.id }));
    }
    if (active && next?.timeline.startedAtEpochMs) {
      if (timer) window.clearInterval(timer);
      timerNode.textContent = formatDuration(Date.now() - next.timeline.startedAtEpochMs);
      timer = window.setInterval(() => {
        timerNode.textContent = formatDuration(Date.now() - (next.timeline.startedAtEpochMs ?? Date.now()));
      }, 1e3);
    } else if (timer) {
      window.clearInterval(timer);
      timer = void 0;
      timerNode.textContent = "";
    }
  }
  function formatDuration(ms) {
    const seconds = Math.floor(ms / 1e3);
    return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }
  async function refresh() {
    tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    titleNode.textContent = tab?.title || "\u65E0\u6CD5\u8BFB\u53D6\u6807\u7B7E\u9875";
    urlNode.textContent = tab?.url || "";
    const response = await chrome.runtime.sendMessage(message("session/status", {}));
    if (response?.session) {
      setState(response.session);
    } else {
      setState(void 0);
    }
  }
  startButton.addEventListener("click", async () => {
    if (!tab?.id) return;
    hideError();
    startButton.disabled = true;
    startButton.hidden = true;
    stopButton.hidden = false;
    stopButton.disabled = true;
    statusNode.textContent = "\u6B63\u5728\u542F\u52A8\u5F55\u5236\u2026";
    dotNode.classList.add("rec");
    try {
      const hasPermission = await chrome.permissions.contains({ origins: ["http://*/*", "https://*/*"] }).catch(() => false);
      if (!hasPermission) {
        const fullAccess = await chrome.permissions.request({ origins: ["http://*/*", "https://*/*"] }).catch(() => false);
        if (!fullAccess) showError("\u672A\u6388\u4E88\u5168\u7AD9\u8BBF\u95EE\u6743\u9650\uFF1A\u5C06\u4EE5\u6709\u9650\u6A21\u5F0F\u5F55\u5236\u5F53\u524D\u9875\u9762\u3002");
      }
      const options = {
        captureAudio: $("#audio").checked,
        privacyMode: $("#privacy").value,
        mediaTimesliceMs: 1e3
      };
      const response = await chrome.runtime.sendMessage(message("session/start", { tabId: tab.id, options, commandId: crypto.randomUUID() }));
      if (!response?.ok) throw new Error(response?.error || "\u5F00\u59CB\u5F55\u5236\u5931\u8D25");
      stopButton.disabled = false;
      setState(response.session);
    } catch (error) {
      showError(error);
      startButton.disabled = false;
      startButton.hidden = false;
      stopButton.hidden = true;
      dotNode.classList.remove("rec");
      statusNode.textContent = "\u672A\u5F55\u5236";
    }
  });
  stopButton.addEventListener("click", async () => {
    stopButton.disabled = true;
    statusNode.textContent = "\u6B63\u5728\u7ED3\u675F\u5F55\u5236\u2026";
    hideError();
    try {
      const response = await chrome.runtime.sendMessage(message("session/stop", { commandId: crypto.randomUUID() }));
      if (!response?.ok) throw new Error(response?.error || "\u7ED3\u675F\u5F55\u5236\u5931\u8D25");
      setState(response.session);
    } catch (error) {
      showError(error);
      stopButton.disabled = false;
    }
  });
  void refresh();
})();
