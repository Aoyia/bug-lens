"use strict";
(() => {
  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 2;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }

  // src/entrypoints/popup/index.ts
  var $ = (selector) => document.querySelector(selector);
  var scopeIds = ["video", "audio", "screenshots", "console", "network", "bodies"];
  var activeSession;
  var activeTab;
  var timer;
  var currentView = "record";
  function setError(error) {
    const node = $("#error");
    node.hidden = !error;
    node.textContent = error ? String(error) : "";
  }
  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KiB`;
    return `${(bytes / 1024 / 1024).toFixed(bytes >= 100 * 1024 * 1024 ? 0 : 1)} MiB`;
  }
  function formatDuration(ms) {
    const seconds = Math.max(0, Math.floor(ms / 1e3));
    return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }
  function isActive(session) {
    return Boolean(session && ["PREPARING", "RECORDING", "DEGRADED", "STOPPING"].includes(session.status));
  }
  function activeEvidence(session) {
    if (!session) return [];
    const issue = (source) => session.quality.issues.some((entry) => entry.source === source);
    const state = (enabled, source) => !enabled ? "disabled" : issue(source) ? "partial" : "captured";
    return [
      { kind: "video", state: state(session.options.captureVideo, "media"), count: 0, sizeBytes: 0, detail: "" },
      { kind: "screenshots", state: state(session.options.captureScreenshots, "screenshot"), count: session.quality.primaryScreenshotCount, sizeBytes: 0, detail: "" },
      { kind: "console", state: state(session.options.captureConsole, "debugger"), count: session.quality.consoleEntryCount, sizeBytes: 0, detail: "" },
      { kind: "network", state: state(session.options.captureNetwork, "debugger"), count: session.quality.networkEntryCount, sizeBytes: 0, detail: "" },
      { kind: "networkBodies", state: !session.options.captureNetworkBodies ? "disabled" : "pending", count: 0, sizeBytes: 0, detail: "" }
    ];
  }
  function evidenceLabel(evidence) {
    return { video: "\u5F55\u50CF", audio: "\u97F3\u9891", screenshots: "\u622A\u56FE", console: "Console", network: "Network", networkBodies: "\u6B63\u6587" }[evidence.kind];
  }
  function renderEvidence(items) {
    return items.map((item) => `<span class="chip ${item.state}" title="${escapeHtml(item.detail)}">${evidenceLabel(item)} \xB7 ${item.state === "captured" ? "\u6210\u529F" : item.state === "partial" ? "\u90E8\u5206" : item.state === "failed" ? "\u5931\u8D25" : item.state === "redacted" ? "\u5DF2\u8131\u654F" : item.state === "pending" ? "\u5904\u7406\u4E2D" : "\u672A\u91C7\u96C6"}</span>`).join("");
  }
  function readOptions() {
    return {
      captureVideo: $("#video").checked,
      captureAudio: $("#audio").checked,
      captureScreenshots: $("#screenshots").checked,
      captureConsole: $("#console").checked,
      captureNetwork: $("#network").checked,
      captureNetworkBodies: $("#bodies").checked,
      privacyMode: $("#privacy").value,
      mediaTimesliceMs: 1e3,
      maxSessionBytes: 512 * 1024 * 1024,
      maxResponseBodyBytes: 2 * 1024 * 1024
    };
  }
  function setControlsLocked(locked) {
    for (const id of scopeIds) $(`#${id}`).disabled = locked;
    $("#privacy").disabled = locked;
  }
  function setState(session) {
    activeSession = session;
    const active = isActive(session);
    const previewReady = Boolean(session && ["PREVIEW_READY", "EXPORTED"].includes(session.status));
    $("#status").textContent = active ? session?.status === "PREPARING" ? "\u6B63\u5728\u542F\u52A8\u5F55\u5236\u2026" : session?.status === "DEGRADED" ? "\u5F55\u5236\u4E2D\uFF08\u90E8\u5206\u8BC1\u636E\u4E0D\u53EF\u7528\uFF09" : "\u5F55\u5236\u4E2D" : previewReady ? "\u5F55\u5236\u5B8C\u6210" : "\u672A\u5F55\u5236";
    $("#dot").classList.toggle("rec", active);
    $("#start").hidden = active || previewReady;
    $("#stop").hidden = !active;
    $("#stop").disabled = session?.status === "STOPPING";
    $("#preview").hidden = !previewReady;
    setControlsLocked(active || previewReady);
    $("#evidence").innerHTML = renderEvidence(activeEvidence(session));
    if (timer) window.clearInterval(timer);
    timer = void 0;
    if (active && session?.timeline.startedAtEpochMs) {
      const update = () => {
        $("#timer").textContent = formatDuration(Date.now() - session.timeline.startedAtEpochMs);
      };
      update();
      timer = window.setInterval(update, 1e3);
    } else $("#timer").textContent = "";
  }
  async function refreshRecord() {
    activeTab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    $("#title").textContent = activeTab?.title || "\u65E0\u6CD5\u8BFB\u53D6\u6807\u7B7E\u9875";
    $("#url").textContent = activeTab?.url || "";
    const response = await chrome.runtime.sendMessage(message("session/status", {}));
    setState(response?.session);
  }
  function isContinuable(session) {
    return session.quality.issues.some((entry) => entry.code.startsWith("SESSION_") || entry.code === "MEDIA_CONTEXT_LOST");
  }
  function sessionHtml(item) {
    const { session } = item;
    const date = new Date(session.timeline.createdAtEpochMs).toLocaleString();
    return `<article class="session">
    <div class="session-head">
      <div class="session-title" title="${escapeHtml(session.target.initialTitle)}">${escapeHtml(session.target.initialTitle || "\u672A\u547D\u540D\u6807\u7B7E\u9875")}</div>
      <div class="session-head-actions">
        ${isContinuable(session) ? `<button class="btn-continue-sm" data-continue="${session.id}">\u6062\u590D</button>` : ""}
        <button class="btn-open-preview" data-open="${session.id}">\u9884\u89C8</button>
        <button class="btn-delete-icon" data-delete="${session.id}" title="\u5220\u9664\u4F1A\u8BDD">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
        </button>
      </div>
    </div>
    <div class="session-meta"><span class="session-status-tag">${escapeHtml(session.status)}</span> \xB7 ${escapeHtml(date)} \xB7 ${formatBytes(item.sizeBytes)} \xB7 ${escapeHtml(session.target.initialUrl)}</div>
    <div class="evidence">${renderEvidence(item.evidence)}</div>
  </article>`;
  }
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
  }
  function renderStorage(storage) {
    $("#storage-used").textContent = `${formatBytes(storage.usedBytes)} \u5DF2\u4F7F\u7528`;
    $("#storage-policy").textContent = `\u81EA\u52A8\u6E05\u7406 ${storage.policy.retentionDays} \u5929\u524D\u4F1A\u8BDD \xB7 \u5355\u4F1A\u8BDD ${formatBytes(storage.policy.maxSessionBytes)}`;
    $("#storage-count").textContent = `${storage.sessionCount} \u4E2A\u4F1A\u8BDD`;
  }
  async function refreshHistory() {
    const query = $("#search").value;
    const [sessionsResponse, storageResponse] = await Promise.all([
      chrome.runtime.sendMessage(message("session/list", { query })),
      chrome.runtime.sendMessage(message("storage/get", {}))
    ]);
    const sessions = sessionsResponse?.sessions ?? [];
    const emptyHtml = `
    <div class="empty-state">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
      <div class="empty-title">\u6682\u65E0\u5339\u914D\u7684\u8BCA\u65AD\u8BB0\u5F55</div>
      <div class="empty-sub">\u5DF2\u5B8C\u6210\u5F55\u5236\u7684\u62A5\u544A\u5C06\u5B58\u653E\u5728\u8FD9\u91CC</div>
    </div>
  `;
    $("#sessions").innerHTML = sessions.length ? sessions.map(sessionHtml).join("") : emptyHtml;
    if (storageResponse?.storage) renderStorage(storageResponse.storage);
  }
  function showView(next) {
    currentView = next;
    $("#record-view").hidden = next !== "record";
    $("#history-view").hidden = next !== "history";
    const mainHeader = $("#main-header");
    const historyHeader = $("#history-header");
    if (mainHeader && historyHeader) {
      mainHeader.hidden = next === "history";
      historyHeader.hidden = next !== "history";
    }
    document.querySelectorAll(".tab").forEach((button) => button.classList.toggle("active", button.dataset.view === next));
    if (next === "history") void refreshHistory().catch(setError);
  }
  $("#start").addEventListener("click", async () => {
    if (!activeTab?.id) return;
    const options = readOptions();
    if (!options.captureVideo && options.captureAudio) {
      setError("\u97F3\u9891\u4F9D\u9644\u4E8E\u5F55\u50CF\uFF1B\u8BF7\u5148\u5F00\u542F\u5F55\u50CF\u3002");
      return;
    }
    if (!options.captureNetwork) options.captureNetworkBodies = false;
    if (options.privacyMode === "raw" && !window.confirm("\u539F\u59CB\u6A21\u5F0F\u4F1A\u4FDD\u7559\u672A\u8131\u654F\u7684\u9875\u9762\u548C\u8C03\u8BD5\u6570\u636E\u3002\u4EC5\u5728\u83B7\u51C6\u4E14\u4F1A\u4EBA\u5DE5\u68C0\u67E5\u7684\u573A\u666F\u4F7F\u7528\u3002")) return;
    setError();
    try {
      const hasPermission = await chrome.permissions.contains({ origins: ["http://*/*", "https://*/*"] }).catch(() => false);
      if (!hasPermission && !await chrome.permissions.request({ origins: ["http://*/*", "https://*/*"] }).catch(() => false)) setError("\u672A\u6388\u4E88\u5168\u7AD9\u8BBF\u95EE\u6743\u9650\uFF1A\u9875\u9762\u4EA4\u4E92\u91C7\u96C6\u53EF\u80FD\u53D7\u9650\u3002");
      const response = await chrome.runtime.sendMessage(message("session/start", { tabId: activeTab.id, options, commandId: crypto.randomUUID() }));
      if (!response?.ok) throw new Error(response?.error || "\u5F00\u59CB\u5F55\u5236\u5931\u8D25");
      setState(response.session);
    } catch (error) {
      setError(error);
      await refreshRecord();
    }
  });
  $("#stop").addEventListener("click", async () => {
    setError();
    try {
      const response = await chrome.runtime.sendMessage(message("session/stop", { commandId: crypto.randomUUID() }));
      if (!response?.ok) throw new Error(response?.error || "\u7ED3\u675F\u5F55\u5236\u5931\u8D25");
      setState(response.session);
    } catch (error) {
      setError(error);
    }
  });
  $("#preview").addEventListener("click", () => {
    if (activeSession) void chrome.runtime.sendMessage(message("session/open-preview", { sessionId: activeSession.id }));
  });
  document.querySelectorAll(".tab").forEach((button) => button.addEventListener("click", () => {
    const targetView = button.dataset.view === "history" ? currentView === "history" ? "record" : "history" : "record";
    showView(targetView);
  }));
  $("#video").addEventListener("change", () => {
    const video = $("#video").checked;
    $("#audio").disabled = !video;
    if (!video) $("#audio").checked = false;
  });
  $("#network").addEventListener("change", () => {
    const network = $("#network").checked;
    $("#bodies").disabled = !network;
    if (!network) $("#bodies").checked = false;
  });
  $("#refresh-history").addEventListener("click", () => void refreshHistory().catch(setError));
  $("#cleanup").addEventListener("click", async () => {
    const response = await chrome.runtime.sendMessage(message("storage/cleanup", {}));
    if (!response?.ok) setError(response?.error || "\u6E05\u7406\u5931\u8D25");
    else await refreshHistory();
  });
  $("#search").addEventListener("input", () => void refreshHistory().catch(setError));
  $("#sessions").addEventListener("click", async (event) => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.open) {
      await chrome.runtime.sendMessage(message("session/open-preview", { sessionId: button.dataset.open }));
      return;
    }
    if (button.dataset.delete) {
      if (window.confirm("\u5220\u9664\u4F1A\u8BDD\u53CA\u5176\u5168\u90E8\u672C\u5730\u8BC1\u636E\uFF1F\u6B64\u64CD\u4F5C\u4E0D\u53EF\u6062\u590D\u3002")) {
        const response = await chrome.runtime.sendMessage(message("session/delete", { sessionId: button.dataset.delete }));
        if (!response?.ok) setError(response?.error || "\u5220\u9664\u5931\u8D25");
        else await refreshHistory();
      }
      return;
    }
    if (button.dataset.continue) {
      const response = await chrome.runtime.sendMessage(message("session/resume", { sessionId: button.dataset.continue, commandId: crypto.randomUUID() }));
      if (!response?.ok) setError(response?.error || "\u7EE7\u7EED\u5F55\u5236\u5931\u8D25");
      else {
        showView("record");
        setState(response.session);
      }
    }
  });
  $("#toggle-options")?.addEventListener("click", () => {
    const panel = $("#advanced-options");
    const btn = $("#toggle-options");
    if (!panel || !btn) return;
    const isHidden = panel.hidden;
    panel.hidden = !isHidden;
    btn.classList.toggle("open", isHidden);
  });
  void refreshRecord().catch(setError);
})();
