"use strict";
(() => {
  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }

  // src/entrypoints/content/interaction-collector.ts
  if (!window.__WEB_BUG_RECORDER_INSTALLED__) {
    let renderRecordingWidget = function() {
      if (widgetContainer || window.top !== window) return;
      const root = document.createElement("div");
      root.id = "__wbr_recording_widget__";
      root.setAttribute("data-wbr-ignore", "true");
      Object.assign(root.style, {
        position: "fixed",
        bottom: "24px",
        right: "24px",
        zIndex: "2147483647",
        display: "flex",
        alignItems: "center",
        gap: "10px",
        padding: "8px 14px",
        background: "#1d2129",
        color: "#ffffff",
        borderRadius: "6px",
        boxShadow: "0 4px 18px rgba(0, 0, 0, 0.28)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        fontSize: "12px",
        lineHeight: "1",
        userSelect: "none"
      });
      root.innerHTML = `
      <style>
        @keyframes wbr-pulse {
          0% { box-shadow: 0 0 0 0 rgba(245, 63, 63, 0.6); }
          70% { box-shadow: 0 0 0 6px rgba(245, 63, 63, 0); }
          100% { box-shadow: 0 0 0 0 rgba(245, 63, 63, 0); }
        }
        .__wbr_dot {
          width: 8px; height: 8px; border-radius: 50%; background: #f53f3f;
          display: inline-block;
          animation: wbr-pulse 1.5s infinite;
        }
        .__wbr_btn {
          border: none; background: #f53f3f; color: #fff; border-radius: 4px;
          padding: 5px 10px; font-size: 11px; font-weight: 500; cursor: pointer;
          transition: background 0.15s ease;
          outline: none;
        }
        .__wbr_btn:hover { background: #f76565; }
        .__wbr_btn:active { background: #cb2727; }
        .__wbr_timer { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 12px; color: #e5e6eb; font-weight: 600; }
      </style>
      <span class="__wbr_dot"></span>
      <span style="font-weight:600;letter-spacing:0.5px;color:#fff;">REC</span>
      <span id="__wbr_timer_display__" class="__wbr_timer">00:00</span>
      <button id="__wbr_stop_btn__" class="__wbr_btn">\u7ED3\u675F\u5F55\u5236</button>
    `;
      const attach = () => {
        if (document.body) {
          document.body.appendChild(root);
          widgetContainer = root;
          const stopBtn = root.querySelector("#__wbr_stop_btn__");
          if (stopBtn) {
            stopBtn.addEventListener("click", (e) => {
              e.stopPropagation();
              e.preventDefault();
              void chrome.runtime.sendMessage(message("session/stop", { commandId: crypto.randomUUID() }));
              removeRecordingWidget();
            }, true);
          }
          const startTime = session?.startedAtEpochMs || Date.now();
          const updateTimer = () => {
            const display = root.querySelector("#__wbr_timer_display__");
            if (display) {
              const sec = Math.floor((Date.now() - startTime) / 1e3);
              const m = String(Math.floor(sec / 60)).padStart(2, "0");
              const s = String(sec % 60).padStart(2, "0");
              display.textContent = `${m}:${s}`;
            }
          };
          updateTimer();
          timerInterval = window.setInterval(updateTimer, 1e3);
        } else {
          window.addEventListener("DOMContentLoaded", attach, { once: true });
        }
      };
      attach();
    }, removeRecordingWidget = function() {
      if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = void 0;
      }
      if (widgetContainer) {
        widgetContainer.remove();
        widgetContainer = void 0;
      }
    }, isWidgetElement = function(el) {
      return Boolean(el && el.closest("#__wbr_recording_widget__"));
    }, textOf = function(element) {
      if (element instanceof HTMLInputElement && element.type.toLowerCase() === "password") return void 0;
      const labelled = element.getAttribute("aria-label") || element.getAttribute("alt") || element.getAttribute("title");
      const text = labelled || (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.value : element.textContent);
      return text?.replace(/\s+/g, " ").trim().slice(0, 256) || void 0;
    }, cssEscape = function(value) {
      return value.replace(/[^a-zA-Z0-9_-]/g, "\\$&");
    }, buildLocators = function(element) {
      const candidates = [];
      const root = element.getRootNode();
      const add = (kind, expression, score, reasons) => {
        let matchCount = 0;
        try {
          matchCount = root.querySelectorAll(expression).length;
        } catch {
          matchCount = 0;
        }
        candidates.push({ kind, expression, matchCount, stabilityScore: score, reasons });
      };
      for (const attr of ["data-testid", "data-test", "data-cy"]) {
        const value = element.getAttribute(attr);
        if (value) add("testId", `[${attr}="${cssEscape(value)}"]`, 0.98, [`${attr} \u662F\u6D4B\u8BD5\u5C5E\u6027`]);
      }
      const role = element.getAttribute("role") || (element.tagName.toLowerCase() === "button" ? "button" : void 0);
      if (role) add("role", `role=${role}`, 0.86, ["\u8BED\u4E49\u89D2\u8272"]);
      if (element.id && !/[0-9a-f]{8,}|uuid|random/i.test(element.id)) add("id", `#${cssEscape(element.id)}`, 0.9, ["\u7A33\u5B9A ID"]);
      const name = element.getAttribute("name");
      if (name) add("attribute", `${element.tagName.toLowerCase()}[name="${cssEscape(name)}"]`, 0.78, ["name \u5C5E\u6027"]);
      const text = textOf(element);
      if (text && text.length < 80) candidates.push({ kind: "text", expression: text, matchCount: 1, stabilityScore: 0.6, reasons: ["\u53EF\u89C1\u6587\u672C\u6458\u8981"] });
      const tag = element.tagName.toLowerCase();
      add("css", tag, 0.25, ["CSS \u515C\u5E95\u5B9A\u4F4D\u5668"]);
      return candidates.sort((a, b) => b.stabilityScore - a.stabilityScore).slice(0, 8);
    }, describe = function(element) {
      const rect = element.getBoundingClientRect();
      const attributes = {};
      for (const attr of Array.from(element.attributes)) {
        if (/^(data-testid|data-test|data-cy|name|type|role|aria-|href)$/.test(attr.name) || attr.name.startsWith("aria-")) attributes[attr.name] = attr.value.slice(0, 512);
      }
      const role = element.getAttribute("role") || void 0;
      return { tagName: element.tagName.toLowerCase(), id: element.id || void 0, classNames: Array.from(element.classList).slice(0, 12), attributes, text: textOf(element), role, accessibleName: element.getAttribute("aria-label") || void 0, boundingBox: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, locators: buildLocators(element) };
    }, firstElement = function(path) {
      return path.find((item) => item instanceof Element);
    }, createRecord = function(event, element, status) {
      const now = Date.now();
      const id = crypto.randomUUID();
      const pointerType = "pointerType" in event ? event.pointerType || "unknown" : "keyboard";
      return { id, sessionId: session.nonce, kind: "click", status, createdAt: now, page: { url: location.href, title: document.title, frameId: 0 }, input: { pointerType, button: event.button ?? 0, isTrusted: event.isTrusted }, coordinates: { clientX: event.clientX, clientY: event.clientY, pageX: event.pageX, pageY: event.pageY, scrollX: window.scrollX, scrollY: window.scrollY, devicePixelRatio: window.devicePixelRatio, viewport: { width: window.innerWidth, height: window.innerHeight } }, element: describe(element), screenshot: { status: "pending" } };
    };
    renderRecordingWidget2 = renderRecordingWidget, removeRecordingWidget2 = removeRecordingWidget, isWidgetElement2 = isWidgetElement, textOf2 = textOf, cssEscape2 = cssEscape, buildLocators2 = buildLocators, describe2 = describe, firstElement2 = firstElement, createRecord2 = createRecord;
    window.__WEB_BUG_RECORDER_INSTALLED__ = true;
    let session;
    const pending = /* @__PURE__ */ new Map();
    let widgetContainer;
    let timerInterval;
    const send = (record, type) => {
      void chrome.runtime.sendMessage(message(type, { interaction: record }, record.sessionId));
    };
    document.addEventListener("pointerdown", (event) => {
      if (!session || !event.isTrusted) return;
      const element = firstElement(event.composedPath());
      if (!element || isWidgetElement(element)) return;
      const record = createRecord(event, element, "candidate");
      pending.set(record.id, record);
      send(record, "interaction/candidate");
      window.setTimeout(() => {
        if (pending.get(record.id)?.status === "candidate") {
          pending.delete(record.id);
          void chrome.runtime.sendMessage(message("interaction/cancelled", { interactionId: record.id }, record.sessionId));
        }
      }, 750);
    }, { capture: true, passive: true });
    document.addEventListener("click", (event) => {
      if (!session || !event.isTrusted) return;
      const element = firstElement(event.composedPath()) ?? (event.target instanceof Element ? event.target : void 0);
      if (!element || isWidgetElement(element)) return;
      const nearest = Array.from(pending.values()).find((candidate) => Math.abs(candidate.coordinates.clientX - event.clientX) < 3 && Math.abs(candidate.coordinates.clientY - event.clientY) < 3);
      const record = nearest ? { ...nearest, status: "confirmed", confirmedAt: Date.now(), element: describe(element) } : createRecord(event, element, "confirmed");
      if (nearest) pending.delete(nearest.id);
      send(record, "interaction/confirmed");
    }, { capture: true, passive: true });
    chrome.runtime.sendMessage(message("content/hello", { url: location.href, title: document.title })).then((response) => {
      if (response?.active && response.sessionId && response.nonce) {
        session = { sessionId: response.sessionId, nonce: response.nonce, startedAtEpochMs: response.startedAtEpochMs };
        window.__WEB_BUG_RECORDER_SESSION__ = session;
        renderRecordingWidget();
      } else {
        removeRecordingWidget();
      }
    }).catch(() => void 0);
  }
  var renderRecordingWidget2;
  var removeRecordingWidget2;
  var isWidgetElement2;
  var textOf2;
  var cssEscape2;
  var buildLocators2;
  var describe2;
  var firstElement2;
  var createRecord2;
})();
