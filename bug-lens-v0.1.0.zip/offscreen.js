"use strict";
(() => {
  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 1;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }
  function isEnvelope(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    return candidate.protocolVersion === PROTOCOL_VERSION && typeof candidate.type === "string" && typeof candidate.messageId === "string";
  }

  // src/storage/db.ts
  var DB_NAME = "web-bug-recorder";
  var DB_VERSION = 4;
  var openPromise;
  function openDb() {
    if (openPromise) return openPromise;
    openPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        const transaction = request.transaction;
        if (!transaction) throw new Error("IndexedDB migration transaction unavailable");
        const ensureStore = (name, keyPath, indexes = []) => {
          const store = database.objectStoreNames.contains(name) ? transaction.objectStore(name) : database.createObjectStore(name, { keyPath });
          for (const index of indexes) {
            if (!store.indexNames.contains(index.name)) store.createIndex(index.name, index.keyPath);
          }
        };
        ensureStore("control", "key");
        ensureStore("sessions", "id", [{ name: "status", keyPath: "status" }]);
        ensureStore("interactions", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("consoleEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("networkEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("mediaChunks", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("exportSelections", "sessionId");
        ensureStore("exportArtifacts", "sessionId");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return openPromise;
  }
  async function put(storeName, value) {
    const db2 = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db2.transaction(storeName, "readwrite");
      tx.objectStore(storeName).put(value);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async function get(storeName, key) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function list(storeName, indexName, key) {
    const db2 = await openDb();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).index(indexName).getAll(key);
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }
  var db = {
    getSession: (id) => get("sessions", id),
    saveSession: (session) => put("sessions", session),
    getActiveSession: async () => {
      const active = await get("control", "active-session");
      return active?.sessionId ? get("sessions", active.sessionId) : void 0;
    },
    claimSession: async (session) => {
      const dbInstance = await openDb();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction(["control", "sessions"], "readwrite");
        const control = tx.objectStore("control");
        const sessions = tx.objectStore("sessions");
        const currentReq = control.get("active-session");
        currentReq.onsuccess = () => {
          const current = currentReq.result;
          if (current?.sessionId) {
            const existingReq = sessions.get(current.sessionId);
            existingReq.onsuccess = () => resolve({ session: existingReq.result, claimed: false });
            existingReq.onerror = () => reject(existingReq.error);
            return;
          }
          sessions.put(session);
          control.put({ key: "active-session", sessionId: session.id });
          resolve({ session, claimed: true });
        };
        tx.onerror = () => reject(tx.error);
      });
    },
    clearActive: async (sessionId) => {
      const current = await get("control", "active-session");
      if (current?.sessionId === sessionId) {
        const dbInstance = await openDb();
        await new Promise((resolve, reject) => {
          const tx = dbInstance.transaction("control", "readwrite");
          tx.objectStore("control").delete("active-session");
          tx.oncomplete = () => resolve();
          tx.onerror = () => reject(tx.error);
        });
      }
    },
    saveInteraction: (record) => put("interactions", record),
    getInteractions: (sessionId) => list("interactions", "sessionId", sessionId),
    saveConsole: (entry) => put("consoleEntries", entry),
    getConsole: (sessionId) => list("consoleEntries", "sessionId", sessionId),
    saveNetwork: (entry) => put("networkEntries", entry),
    getNetwork: (sessionId) => list("networkEntries", "sessionId", sessionId),
    saveMediaChunk: (chunk) => put("mediaChunks", chunk),
    getMediaChunks: (sessionId) => list("mediaChunks", "sessionId", sessionId),
    getExportSelection: (sessionId) => get("exportSelections", sessionId),
    saveExportSelection: (selection) => put("exportSelections", selection),
    getExportArtifact: (sessionId) => get("exportArtifacts", sessionId),
    saveExportArtifact: (artifact) => put("exportArtifacts", artifact)
  };

  // src/entrypoints/offscreen/index.ts
  var recorder;
  var capturedStream;
  var sequence = 0;
  var activeSessionId;
  var pendingWrites = /* @__PURE__ */ new Set();
  function chooseMimeType(audio) {
    const candidates = audio ? ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"] : ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
    return candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate));
  }
  async function startMedia(payload) {
    activeSessionId = payload.sessionId;
    sequence = 0;
    const constraints = {
      video: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: payload.streamId } },
      audio: payload.captureAudio ? { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: payload.streamId } } : false
    };
    try {
      capturedStream = await navigator.mediaDevices.getUserMedia(constraints);
      if (payload.captureAudio && capturedStream.getAudioTracks().length) {
        const audioContext = new AudioContext();
        const source = audioContext.createMediaStreamSource(new MediaStream(capturedStream.getAudioTracks()));
        source.connect(audioContext.destination);
      }
      const recordingStream = new MediaStream([...capturedStream.getVideoTracks(), ...payload.captureAudio ? capturedStream.getAudioTracks() : []]);
      recorder = new MediaRecorder(recordingStream, { mimeType: chooseMimeType(payload.captureAudio) });
      recorder.ondataavailable = (event) => {
        if (!event.data.size || !activeSessionId) return;
        const sessionId = activeSessionId;
        const chunkSequence = sequence++;
        const mimeType = event.data.type || recorder?.mimeType || "video/webm";
        const write = event.data.arrayBuffer().then((buffer) => db.saveMediaChunk({ id: `${sessionId}:${chunkSequence}`, sessionId, chunk: buffer, sequence: chunkSequence, mimeType, recordedAt: Date.now() }));
        pendingWrites.add(write);
        void write.catch((error) => chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId, state: "error", error: `\u5A92\u4F53\u5206\u7247\u5199\u5165\u5931\u8D25\uFF1A${String(error)}` }, sessionId))).finally(() => pendingWrites.delete(write));
      };
      recorder.onerror = (event) => {
        void chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId: activeSessionId, state: "error", error: String(event.error ?? "MediaRecorder error") }, activeSessionId));
      };
      capturedStream.getTracks().forEach((track) => track.addEventListener("ended", () => {
        if (recorder?.state === "recording") void chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId: activeSessionId, state: "error", error: "\u5A92\u4F53\u8F68\u9053\u610F\u5916\u7ED3\u675F" }, activeSessionId));
      }));
      recorder.start(Math.max(250, payload.timesliceMs));
      await chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId: payload.sessionId, state: "started" }, payload.sessionId));
    } catch (error) {
      await chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId: payload.sessionId, state: "error", error: String(error) }, payload.sessionId));
    }
  }
  async function stopMedia(sessionId) {
    if (recorder && recorder.state !== "inactive") {
      await new Promise((resolve) => {
        recorder.addEventListener("stop", () => resolve(), { once: true });
        recorder.stop();
      });
    }
    await Promise.allSettled([...pendingWrites]);
    capturedStream?.getTracks().forEach((track) => track.stop());
    capturedStream = void 0;
    recorder = void 0;
    activeSessionId = void 0;
    await chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId, state: "stopped" }, sessionId));
  }
  async function annotateImage(payload) {
    const response = await fetch(payload.dataUrl);
    const bitmap = await createImageBitmap(await response.blob());
    try {
      const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas 2D context unavailable");
      context.drawImage(bitmap, 0, 0);
      const x = payload.clientX * (bitmap.width / Math.max(1, payload.viewportWidth));
      const y = payload.clientY * (bitmap.height / Math.max(1, payload.viewportHeight));
      const radius = Math.max(12, Math.min(bitmap.width, bitmap.height) * 0.018);
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.lineWidth = Math.max(7, radius * 0.45);
      context.strokeStyle = "rgba(255,255,255,.95)";
      context.stroke();
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.lineWidth = Math.max(3, radius * 0.22);
      context.strokeStyle = "#ef233c";
      context.stroke();
      const blob = await canvas.convertToBlob({ type: "image/png" });
      return await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
      });
    } finally {
      bitmap.close();
    }
  }
  chrome.runtime.onMessage.addListener((raw) => {
    if (!isEnvelope(raw)) return;
    const incoming = raw;
    if (incoming.type === "offscreen/start-media") return startMedia(incoming.payload).then(() => ({ ok: true })).catch((error) => ({ ok: false, error: String(error) }));
    if (incoming.type === "offscreen/stop-media") return stopMedia(incoming.payload.sessionId).then(() => ({ ok: true })).catch((error) => ({ ok: false, error: String(error) }));
    if (incoming.type === "offscreen/annotate-image") return annotateImage(incoming.payload).then((dataUrl) => ({ ok: true, dataUrl })).catch((error) => ({ ok: false, error: String(error) }));
  });
})();
