"use strict";
(() => {
  // src/shared/protocol.ts
  var PROTOCOL_VERSION = 2;
  function message(type, payload, sessionId) {
    return { protocolVersion: PROTOCOL_VERSION, messageId: crypto.randomUUID(), type, sentAt: Date.now(), sessionId, payload };
  }
  function isEnvelope(value) {
    if (!value || typeof value !== "object") return false;
    const candidate = value;
    return candidate.protocolVersion === PROTOCOL_VERSION && typeof candidate.type === "string" && typeof candidate.messageId === "string";
  }

  // src/domain/storage-policy.ts
  var DEFAULT_STORAGE_POLICY = {
    retentionDays: 14,
    maxSessionBytes: 512 * 1024 * 1024,
    maxResponseBodyBytes: 2 * 1024 * 1024,
    compression: "balanced"
  };
  var DEFAULT_RECORDING_OPTIONS = {
    captureAudio: false,
    captureVideo: true,
    captureScreenshots: true,
    captureConsole: true,
    captureNetwork: true,
    captureNetworkBodies: true,
    privacyMode: "safe",
    mediaTimesliceMs: 1e3,
    maxResponseBodyBytes: DEFAULT_STORAGE_POLICY.maxResponseBodyBytes,
    maxSessionBytes: DEFAULT_STORAGE_POLICY.maxSessionBytes
  };
  function boundedInteger(value, fallback, min, max) {
    const number = typeof value === "number" && Number.isFinite(value) ? Math.round(value) : fallback;
    return Math.min(max, Math.max(min, number));
  }
  function normalizeStoragePolicy(value) {
    return {
      retentionDays: boundedInteger(value?.retentionDays, DEFAULT_STORAGE_POLICY.retentionDays, 1, 365),
      maxSessionBytes: boundedInteger(value?.maxSessionBytes, DEFAULT_STORAGE_POLICY.maxSessionBytes, 16 * 1024 * 1024, 4 * 1024 * 1024 * 1024),
      maxResponseBodyBytes: boundedInteger(value?.maxResponseBodyBytes, DEFAULT_STORAGE_POLICY.maxResponseBodyBytes, 16 * 1024, 64 * 1024 * 1024),
      compression: value?.compression === "quality" || value?.compression === "small" ? value.compression : "balanced"
    };
  }
  function expiresAt(createdAtEpochMs, retentionDays) {
    return createdAtEpochMs + retentionDays * 24 * 60 * 60 * 1e3;
  }
  function isExpired(createdAtEpochMs, retentionDays, now = Date.now()) {
    return expiresAt(createdAtEpochMs, retentionDays) <= now;
  }
  function estimateBytes(value) {
    const seen = /* @__PURE__ */ new WeakSet();
    const measure = (current) => {
      if (current == null) return 0;
      if (typeof current === "string") return new TextEncoder().encode(current).byteLength;
      if (typeof current === "number" || typeof current === "boolean") return 8;
      if (current instanceof ArrayBuffer) return current.byteLength;
      if (ArrayBuffer.isView(current)) return current.byteLength;
      if (Array.isArray(current)) return current.reduce((total, item) => total + measure(item), 0);
      if (typeof current === "object") {
        if (seen.has(current)) return 0;
        seen.add(current);
        return Object.entries(current).reduce((total, [key, item]) => total + new TextEncoder().encode(key).byteLength + measure(item), 0);
      }
      return 0;
    };
    return measure(value);
  }

  // src/storage/evidence-summary.ts
  function hasIssue(session, source) {
    return session.quality.issues.some((entry) => entry.source === source);
  }
  function enabledState(enabled, count, failed) {
    if (!enabled) return "disabled";
    if (failed && count === 0) return "failed";
    if (failed) return "partial";
    return "captured";
  }
  function buildEvidenceSummary(session, media, networkEntries) {
    const screenshotCount = session.quality.primaryScreenshotCount + session.quality.fallbackScreenshotCount;
    const unavailableScreenshots = session.quality.unavailableScreenshotCount;
    const networkBodyEntries = networkEntries.filter((entry) => entry.response);
    const bodyBytes = networkBodyEntries.reduce((total, entry) => total + (entry.response?.capturedByteLength ?? entry.response?.byteLength ?? 0), 0);
    const redactedBodyCount = networkBodyEntries.filter((entry) => entry.response?.bodyStatus === "redacted").length;
    const truncatedBodyCount = networkBodyEntries.filter((entry) => entry.response?.truncated).length;
    const unavailableBodyCount = networkBodyEntries.filter((entry) => entry.response?.bodyStatus === "unavailable" || entry.response?.bodyStatus === "pending").length;
    const videoState = enabledState(session.options.captureVideo, media.count, hasIssue(session, "media"));
    const screenshotState = !session.options.captureScreenshots ? "disabled" : unavailableScreenshots ? screenshotCount ? "partial" : "failed" : "captured";
    const consoleState = enabledState(session.options.captureConsole, session.quality.consoleEntryCount, hasIssue(session, "debugger"));
    const networkState = enabledState(session.options.captureNetwork, session.quality.networkEntryCount, hasIssue(session, "debugger"));
    let bodiesState = "disabled";
    if (session.options.captureNetwork && session.options.captureNetworkBodies) {
      bodiesState = redactedBodyCount ? "redacted" : unavailableBodyCount ? networkBodyEntries.length ? "partial" : "failed" : "captured";
    }
    return [
      { kind: "video", state: videoState, count: media.count, sizeBytes: 0, detail: media.count ? `${media.count} \u4E2A WebM \u5206\u7247` : "\u672A\u5199\u5165\u5F55\u50CF" },
      { kind: "audio", state: !session.options.captureAudio ? "disabled" : videoState, count: session.options.captureAudio && media.count ? 1 : 0, sizeBytes: 0, detail: session.options.captureAudio ? "\u4E0E\u6807\u7B7E\u9875\u5F55\u50CF\u590D\u7528\u540C\u4E00 WebM" : "\u672A\u91C7\u96C6" },
      { kind: "screenshots", state: screenshotState, count: screenshotCount, sizeBytes: 0, detail: !session.options.captureScreenshots ? "\u672A\u91C7\u96C6" : unavailableScreenshots ? `${screenshotCount} \u6210\u529F\uFF0C${unavailableScreenshots} \u5931\u8D25` : `${screenshotCount} \u5F20` },
      { kind: "console", state: consoleState, count: session.quality.consoleEntryCount, sizeBytes: 0, detail: `${session.quality.consoleEntryCount} \u6761` },
      { kind: "network", state: networkState, count: session.quality.networkEntryCount, sizeBytes: 0, detail: `${session.quality.networkEntryCount} \u6761` },
      { kind: "networkBodies", state: bodiesState, count: networkBodyEntries.length, sizeBytes: bodyBytes, detail: !session.options.captureNetworkBodies ? "\u672A\u91C7\u96C6" : redactedBodyCount ? `${redactedBodyCount} \u6761\u5DF2\u8131\u654F${truncatedBodyCount ? `\uFF0C${truncatedBodyCount} \u6761\u5DF2\u622A\u65AD` : ""}` : truncatedBodyCount ? `${truncatedBodyCount} \u6761\u5DF2\u622A\u65AD` : `${networkBodyEntries.length} \u6761` }
    ];
  }

  // src/storage/indexed-db-schema.ts
  var DB_NAME = "web-bug-recorder";
  var DB_VERSION = 5;
  var openPromise;
  function openEvidenceDatabase() {
    if (openPromise) return openPromise;
    openPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        const transaction = request.transaction;
        if (!transaction) throw new Error("IndexedDB \u6570\u636E\u5E93\u5347\u7EA7/\u8FC1\u79FB\u4E8B\u52A1\u4E0D\u53EF\u7528");
        const ensureStore = (name, keyPath, indexes = []) => {
          const store = database.objectStoreNames.contains(name) ? transaction.objectStore(name) : database.createObjectStore(name, { keyPath });
          for (const index of indexes) {
            if (!store.indexNames.contains(index.name)) store.createIndex(index.name, index.keyPath);
          }
        };
        ensureStore("control", "key");
        ensureStore("sessions", "id", [{ name: "status", keyPath: "status" }]);
        ensureStore("interactions", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("consoleEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("networkEntries", "id", [{ name: "sessionId", keyPath: "sessionId" }]);
        ensureStore("mediaChunks", "id", [
          { name: "sessionId", keyPath: "sessionId" },
          { name: "sessionIdSequence", keyPath: ["sessionId", "sequence"] }
        ]);
        ensureStore("exportSelections", "sessionId");
        ensureStore("exportArtifacts", "sessionId");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return openPromise;
  }

  // src/storage/session-deletion.ts
  async function deleteSessionAndEvidence(sessionId) {
    const database = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const stores = ["sessions", "interactions", "consoleEntries", "networkEntries", "mediaChunks", "exportSelections", "exportArtifacts", "control"];
      const transaction = database.transaction(stores, "readwrite");
      let existed = false;
      const sessions = transaction.objectStore("sessions");
      const sessionRequest = sessions.get(sessionId);
      sessionRequest.onsuccess = () => {
        existed = Boolean(sessionRequest.result);
        sessions.delete(sessionId);
      };
      sessionRequest.onerror = () => reject(sessionRequest.error);
      for (const storeName of ["interactions", "consoleEntries", "networkEntries", "mediaChunks"]) {
        const cursorRequest = transaction.objectStore(storeName).index("sessionId").openKeyCursor(IDBKeyRange.only(sessionId));
        cursorRequest.onsuccess = () => {
          const cursor = cursorRequest.result;
          if (!cursor) return;
          transaction.objectStore(storeName).delete(cursor.primaryKey);
          cursor.continue();
        };
        cursorRequest.onerror = () => reject(cursorRequest.error);
      }
      transaction.objectStore("exportSelections").delete(sessionId);
      transaction.objectStore("exportArtifacts").delete(sessionId);
      const activeRequest = transaction.objectStore("control").get("active-session");
      activeRequest.onsuccess = () => {
        if (activeRequest.result?.sessionId === sessionId) transaction.objectStore("control").delete("active-session");
      };
      activeRequest.onerror = () => reject(activeRequest.error);
      transaction.oncomplete = () => resolve(existed);
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error ?? new Error("\u4F1A\u8BDD\u5220\u9664\u4E8B\u52A1\u5DF2\u4E2D\u6B62"));
    });
  }

  // src/storage/storage-budget.ts
  async function putWithinSessionBudget(storeName, value) {
    const database = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction([storeName, "sessions"], "readwrite");
      const store = transaction.objectStore(storeName);
      const sessions = transaction.objectStore("sessions");
      let result;
      const sessionRequest = sessions.get(value.sessionId);
      sessionRequest.onsuccess = () => {
        const session = sessionRequest.result;
        if (!session) {
          result = { stored: false, usedBytes: 0, limitReached: false };
          return;
        }
        const valueRequest = store.get(value.id ?? value.sessionId);
        valueRequest.onsuccess = () => {
          const previous = valueRequest.result;
          const delta = Math.max(0, estimateBytes(value) - estimateBytes(previous));
          const usedBytes = session.storage?.usedBytes ?? 0;
          if (usedBytes + delta > session.options.maxSessionBytes) {
            sessions.put({ ...session, storage: { usedBytes, limitReached: true } });
            result = { stored: false, usedBytes, limitReached: true };
            return;
          }
          const nextUsedBytes = Math.max(0, usedBytes + estimateBytes(value) - estimateBytes(previous));
          store.put(value);
          sessions.put({ ...session, storage: { usedBytes: nextUsedBytes, limitReached: false } });
          result = { stored: true, usedBytes: nextUsedBytes, limitReached: false };
        };
        valueRequest.onerror = () => reject(valueRequest.error);
      };
      sessionRequest.onerror = () => reject(sessionRequest.error);
      transaction.oncomplete = () => result ? resolve(result) : reject(new Error("\u8BC1\u636E\u5199\u5165\u4E8B\u52A1\u672A\u4EA7\u751F\u7ED3\u679C"));
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error ?? new Error("\u8BC1\u636E\u5199\u5165\u4E8B\u52A1\u5DF2\u4E2D\u6B62"));
    });
  }

  // src/storage/db.ts
  async function put(storeName, value) {
    const db2 = await openEvidenceDatabase();
    await new Promise((resolve, reject) => {
      const tx = db2.transaction(storeName, "readwrite");
      tx.objectStore(storeName).put(value);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
  async function get(storeName, key) {
    const db2 = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  async function list(storeName, indexName, key) {
    const db2 = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).index(indexName).getAll(key);
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }
  async function listAll(storeName) {
    const db2 = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const req = db2.transaction(storeName).objectStore(storeName).getAll();
      req.onsuccess = () => resolve(req.result ?? []);
      req.onerror = () => reject(req.error);
    });
  }
  async function update(storeName, key, mutate) {
    const db2 = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction(storeName, "readwrite");
      const store = tx.objectStore(storeName);
      let next;
      const request = store.get(key);
      request.onsuccess = () => {
        const current = request.result;
        if (!current) return;
        try {
          next = mutate(current);
          store.put(next);
        } catch (error) {
          tx.abort();
          reject(error);
        }
      };
      request.onerror = () => reject(request.error);
      tx.oncomplete = () => resolve(next);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error ?? new Error(`\u66F4\u65B0 ${storeName} \u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62`));
    });
  }
  async function listMediaChunkBatch(sessionId, afterSequence, limit) {
    const db2 = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction("mediaChunks");
      const index = tx.objectStore("mediaChunks").index("sessionIdSequence");
      const range = IDBKeyRange.bound(
        [sessionId, Math.max(0, afterSequence)],
        [sessionId, Number.MAX_SAFE_INTEGER],
        afterSequence >= 0,
        false
      );
      const records = [];
      const request = index.openCursor(range);
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor || records.length >= limit) {
          resolve(records);
          return;
        }
        records.push(cursor.value);
        cursor.continue();
      };
      request.onerror = () => reject(request.error);
    });
  }
  async function getMediaSummary(sessionId) {
    const db2 = await openEvidenceDatabase();
    return new Promise((resolve, reject) => {
      const tx = db2.transaction("mediaChunks");
      const index = tx.objectStore("mediaChunks").index("sessionIdSequence");
      const range = IDBKeyRange.bound([sessionId, 0], [sessionId, Number.MAX_SAFE_INTEGER]);
      const countRequest = index.count(range);
      const firstRequest = index.openCursor(range);
      let count;
      let mimeType;
      const finish = () => {
        if (count != null && firstRequest.readyState === "done") resolve({ count, mimeType });
      };
      countRequest.onsuccess = () => {
        count = countRequest.result;
        finish();
      };
      countRequest.onerror = () => reject(countRequest.error);
      firstRequest.onsuccess = () => {
        const first = firstRequest.result?.value;
        mimeType = first?.mimeType;
        finish();
      };
      firstRequest.onerror = () => reject(firstRequest.error);
    });
  }
  async function measureSessionBytes(sessionId) {
    const [interactions, consoleEntries, networkEntries, chunks] = await Promise.all([
      list("interactions", "sessionId", sessionId),
      list("consoleEntries", "sessionId", sessionId),
      list("networkEntries", "sessionId", sessionId),
      list("mediaChunks", "sessionId", sessionId)
    ]);
    return [...interactions, ...consoleEntries, ...networkEntries, ...chunks].reduce((total, entry) => total + estimateBytes(entry), 0);
  }
  async function evidenceFor(session) {
    const [media, networkEntries] = await Promise.all([
      getMediaSummary(session.id),
      list("networkEntries", "sessionId", session.id)
    ]);
    return buildEvidenceSummary(session, media, networkEntries);
  }
  var db = {
    getSession: (id) => get("sessions", id),
    listSessions: async (limit = 10) => (await listAll("sessions")).sort((left, right) => right.timeline.createdAtEpochMs - left.timeline.createdAtEpochMs).slice(0, Math.max(0, limit)),
    listSessionOverviews: async (query = "") => {
      const normalizedQuery = query.trim().toLocaleLowerCase();
      const [policy, allSessions] = await Promise.all([db.getStoragePolicy(), listAll("sessions")]);
      const sessions = allSessions.filter((session) => !normalizedQuery || [session.target.initialTitle, session.target.initialUrl, session.status, session.id].some((value) => value.toLocaleLowerCase().includes(normalizedQuery))).sort((left, right) => right.timeline.createdAtEpochMs - left.timeline.createdAtEpochMs);
      return Promise.all(sessions.map(async (session) => {
        const sizeBytes = session.storage?.usedBytes ?? await measureSessionBytes(session.id);
        return {
          session,
          evidence: await evidenceFor(session),
          sizeBytes,
          expiresAtEpochMs: expiresAt(session.timeline.createdAtEpochMs, policy.retentionDays)
        };
      }));
    },
    saveSession: (session) => put("sessions", session),
    updateSession: async (id, update2) => {
      const dbInstance = await openEvidenceDatabase();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction("sessions", "readwrite");
        const store = tx.objectStore("sessions");
        let next;
        const request = store.get(id);
        request.onsuccess = () => {
          const current = request.result;
          if (!current) return;
          try {
            next = update2(current);
            store.put(next);
          } catch (error) {
            tx.abort();
            reject(error);
          }
        };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => resolve(next);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u66F4\u65B0\u4F1A\u8BDD\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    updateSessionAndClearActive: async (id, update2) => {
      const dbInstance = await openEvidenceDatabase();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction(["sessions", "control"], "readwrite");
        const sessions = tx.objectStore("sessions");
        const control = tx.objectStore("control");
        let next;
        const sessionRequest = sessions.get(id);
        sessionRequest.onsuccess = () => {
          const current = sessionRequest.result;
          if (!current) return;
          try {
            next = update2(current);
            sessions.put(next);
          } catch (error) {
            tx.abort();
            reject(error);
          }
        };
        sessionRequest.onerror = () => reject(sessionRequest.error);
        const activeRequest = control.get("active-session");
        activeRequest.onsuccess = () => {
          const active = activeRequest.result;
          if (active?.sessionId === id) control.delete("active-session");
        };
        activeRequest.onerror = () => reject(activeRequest.error);
        tx.oncomplete = () => resolve(next);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u4F1A\u8BDD\u5B8C\u6210\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    getActiveSession: async () => {
      const active = await get("control", "active-session");
      return active?.sessionId ? get("sessions", active.sessionId) : void 0;
    },
    claimSession: async (session) => {
      const dbInstance = await openEvidenceDatabase();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction(["control", "sessions"], "readwrite");
        const control = tx.objectStore("control");
        const sessions = tx.objectStore("sessions");
        let result;
        const claim = () => {
          sessions.put(session);
          control.put({ key: "active-session", sessionId: session.id });
          if (session.commandIds?.start) control.put({ key: `command:${session.commandIds.start}`, commandId: session.commandIds.start, kind: "start", sessionId: session.id, createdAtEpochMs: Date.now() });
          result = { session, claimed: true };
        };
        const currentReq = control.get("active-session");
        currentReq.onsuccess = () => {
          const current = currentReq.result;
          if (current?.sessionId) {
            const existingReq = sessions.get(current.sessionId);
            existingReq.onsuccess = () => {
              const existing = existingReq.result;
              if (existing && ["PREPARING", "RECORDING", "DEGRADED", "STOPPING"].includes(existing.status)) {
                result = { session: existing, claimed: false };
              } else {
                claim();
              }
            };
            existingReq.onerror = () => reject(existingReq.error);
            return;
          }
          claim();
        };
        tx.oncomplete = () => result ? resolve(result) : reject(new Error("\u4F1A\u8BDD\u5360\u7528\u4E8B\u52A1\u5DF2\u5B8C\u6210\u4F46\u65E0\u6709\u6548\u7ED3\u679C"));
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u4F1A\u8BDD\u5360\u7528\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    clearActive: async (sessionId) => {
      const dbInstance = await openEvidenceDatabase();
      await new Promise((resolve, reject) => {
        const tx = dbInstance.transaction("control", "readwrite");
        const store = tx.objectStore("control");
        const request = store.get("active-session");
        request.onsuccess = () => {
          const current = request.result;
          if (current?.sessionId === sessionId) store.delete("active-session");
        };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u6D3B\u52A8\u4F1A\u8BDD\u6E05\u7406\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    getCommand: (commandId) => get("control", `command:${commandId}`),
    claimCommand: async (command) => {
      const dbInstance = await openEvidenceDatabase();
      return new Promise((resolve, reject) => {
        const tx = dbInstance.transaction("control", "readwrite");
        const store = tx.objectStore("control");
        const key = `command:${command.commandId}`;
        let result;
        const request = store.get(key);
        request.onsuccess = () => {
          const existing = request.result;
          if (existing) {
            result = { command: existing, claimed: false };
            return;
          }
          const next = { key, ...command };
          store.put(next);
          result = { command: next, claimed: true };
        };
        request.onerror = () => reject(request.error);
        tx.oncomplete = () => result ? resolve(result) : reject(new Error("\u6307\u4EE4\u5360\u7528\u4E8B\u52A1\u5DF2\u5B8C\u6210\u4F46\u65E0\u6709\u6548\u7ED3\u679C"));
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error ?? new Error("\u6307\u4EE4\u5360\u7528\u4E8B\u52A1\u5DF2\u88AB\u4E2D\u6B62"));
      });
    },
    getInteraction: (id) => get("interactions", id),
    saveInteraction: (record) => put("interactions", record),
    saveInteractionWithinBudget: (record) => putWithinSessionBudget("interactions", record),
    getInteractions: (sessionId) => list("interactions", "sessionId", sessionId),
    saveConsole: (entry) => put("consoleEntries", entry),
    saveConsoleWithinBudget: (entry) => putWithinSessionBudget("consoleEntries", entry),
    getConsole: (sessionId) => list("consoleEntries", "sessionId", sessionId),
    saveNetwork: (entry) => put("networkEntries", entry),
    saveNetworkWithinBudget: (entry) => putWithinSessionBudget("networkEntries", entry),
    getNetworkEntry: (id) => get("networkEntries", id),
    updateNetworkEntry: (id, mutate) => update("networkEntries", id, mutate),
    updateNetworkEntryWithinBudget: async (id, mutate) => {
      const current = await get("networkEntries", id);
      if (!current) return { stored: false, usedBytes: 0, limitReached: false };
      return putWithinSessionBudget("networkEntries", mutate(current));
    },
    getNetwork: async (sessionId) => (await list("networkEntries", "sessionId", sessionId)).sort((left, right) => left.createdAt - right.createdAt),
    saveMediaChunk: (chunk) => put("mediaChunks", chunk),
    saveMediaChunkWithinBudget: (chunk) => putWithinSessionBudget("mediaChunks", chunk),
    getMediaSummary,
    getMediaChunks: async (sessionId) => (await list("mediaChunks", "sessionId", sessionId)).sort((left, right) => left.sequence - right.sequence),
    iterateMediaChunks: async (sessionId, visitor, batchSize = 16) => {
      let afterSequence = -1;
      let visited = 0;
      const size = Math.max(1, Math.floor(batchSize));
      while (true) {
        const batch = await listMediaChunkBatch(sessionId, afterSequence, size);
        if (!batch.length) return visited;
        for (const chunk of batch) {
          await visitor(chunk);
          afterSequence = chunk.sequence;
          visited += 1;
        }
        if (batch.length < size) return visited;
      }
    },
    getExportSelection: (sessionId) => get("exportSelections", sessionId),
    saveExportSelection: (selection) => put("exportSelections", selection),
    getExportArtifact: (sessionId) => get("exportArtifacts", sessionId),
    saveExportArtifact: (artifact) => put("exportArtifacts", artifact),
    getStoragePolicy: async () => {
      const stored = await get("control", "storage-policy");
      return normalizeStoragePolicy(stored?.policy ?? DEFAULT_STORAGE_POLICY);
    },
    saveStoragePolicy: async (policy) => {
      const next = normalizeStoragePolicy(policy);
      await put("control", { key: "storage-policy", policy: next });
      return next;
    },
    getStorageOverview: async () => {
      const [policy, sessions] = await Promise.all([db.getStoragePolicy(), listAll("sessions")]);
      const usedBytes = (await Promise.all(sessions.map((session) => session.storage?.usedBytes ?? measureSessionBytes(session.id)))).reduce((total, value) => total + value, 0);
      const estimate = typeof navigator !== "undefined" && navigator.storage?.estimate ? await navigator.storage.estimate().catch(() => void 0) : void 0;
      return { usedBytes, quotaBytes: estimate?.quota ?? Math.max(usedBytes, policy.maxSessionBytes), sessionCount: sessions.length, policy };
    },
    deleteSession: deleteSessionAndEvidence,
    cleanupExpiredSessions: async (now = Date.now()) => {
      const [policy, sessions, active] = await Promise.all([db.getStoragePolicy(), listAll("sessions"), db.getActiveSession()]);
      const expired = sessions.filter((session) => session.id !== active?.id && isExpired(session.timeline.createdAtEpochMs, policy.retentionDays, now));
      await Promise.all(expired.map((session) => deleteSessionAndEvidence(session.id)));
      return expired.map((session) => session.id);
    }
  };

  // src/entrypoints/offscreen/index.ts
  var recorder;
  var capturedStream;
  var playbackContext;
  var sequence = 0;
  var activeSessionId;
  var mediaLimitReached = false;
  var pendingWrites = /* @__PURE__ */ new Set();
  function withTimeout(promise, timeoutMs, messageText) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(messageText)), timeoutMs);
      promise.then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (error) => {
          clearTimeout(timer);
          reject(error);
        }
      );
    });
  }
  function chooseMimeType(audio) {
    const candidates = audio ? ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"] : ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
    return candidates.find((candidate) => MediaRecorder.isTypeSupported(candidate));
  }
  async function startMedia(payload) {
    if (recorder && recorder.state !== "inactive") throw new Error("\u5A92\u4F53\u5F55\u5236\u5DF2\u5728\u8FDB\u884C\u4E2D (MEDIA_ALREADY_RECORDING)");
    activeSessionId = payload.sessionId;
    sequence = 0;
    mediaLimitReached = false;
    const constraints = {
      video: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: payload.streamId } },
      audio: payload.captureAudio ? { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: payload.streamId } } : false
    };
    try {
      capturedStream = await navigator.mediaDevices.getUserMedia(constraints);
      if (payload.captureAudio && capturedStream.getAudioTracks().length) {
        playbackContext = new AudioContext();
        const source = playbackContext.createMediaStreamSource(new MediaStream(capturedStream.getAudioTracks()));
        source.connect(playbackContext.destination);
      }
      const recordingStream = new MediaStream([...capturedStream.getVideoTracks(), ...payload.captureAudio ? capturedStream.getAudioTracks() : []]);
      recorder = new MediaRecorder(recordingStream, {
        mimeType: chooseMimeType(payload.captureAudio),
        videoBitsPerSecond: 25e5,
        audioBitsPerSecond: payload.captureAudio ? 128e3 : void 0
      });
      recorder.ondataavailable = (event) => {
        if (!event.data.size || !activeSessionId || mediaLimitReached) return;
        const sessionId = activeSessionId;
        const chunkSequence = sequence++;
        const mimeType = event.data.type || recorder?.mimeType || "video/webm";
        let write;
        write = event.data.arrayBuffer().then(async (buffer) => {
          const result = await db.saveMediaChunkWithinBudget({ id: `${sessionId}:${chunkSequence}`, sessionId, chunk: buffer, sequence: chunkSequence, mimeType, recordedAt: Date.now() });
          if (result.stored) return;
          mediaLimitReached = true;
          await chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId, state: "error", error: "SESSION_STORAGE_LIMIT_REACHED: \u5DF2\u505C\u6B62\u5F55\u50CF\u4EE5\u9075\u5B88\u5355\u4F1A\u8BDD\u5927\u5C0F\u9650\u5236\u3002" }, sessionId)).catch(() => void 0);
          if (recorder?.state === "recording") recorder.stop();
        }).catch(async (error) => {
          await chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId, state: "error", error: `\u5A92\u4F53\u5206\u7247\u5199\u5165\u5931\u8D25\uFF1A${String(error)}` }, sessionId)).catch(() => void 0);
          throw error;
        }).finally(() => pendingWrites.delete(write));
        pendingWrites.add(write);
        void write.catch(() => void 0);
      };
      recorder.onerror = (event) => {
        void chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId: activeSessionId, state: "error", error: String(event.error ?? "MediaRecorder error") }, activeSessionId));
      };
      capturedStream.getTracks().forEach((track) => track.addEventListener("ended", () => {
        if (recorder?.state === "recording") void chrome.runtime.sendMessage(message("offscreen/media-state", { sessionId: activeSessionId, state: "error", error: "\u5A92\u4F53\u8F68\u9053\u610F\u5916\u7ED3\u675F" }, activeSessionId));
      }));
      recorder.start(Math.max(250, payload.timesliceMs));
    } catch (error) {
      capturedStream?.getTracks().forEach((track) => track.stop());
      capturedStream = void 0;
      recorder = void 0;
      activeSessionId = void 0;
      await playbackContext?.close().catch(() => void 0);
      playbackContext = void 0;
      throw error;
    }
  }
  async function stopMedia(sessionId) {
    if (activeSessionId && activeSessionId !== sessionId) throw new Error(`\u5A92\u4F53\u4F1A\u8BDD\u4E0D\u5339\u914D (MEDIA_SESSION_MISMATCH:${activeSessionId})`);
    let stopError;
    try {
      if (recorder && recorder.state !== "inactive") {
        await withTimeout(new Promise((resolve) => {
          recorder.addEventListener("stop", () => resolve(), { once: true });
          recorder.stop();
        }), 5e3, "\u505C\u6B62\u5A92\u4F53\u5F55\u5236\u8D85\u65F6 (MEDIA_STOP_TIMEOUT)");
      }
    } catch (error) {
      stopError = error;
    }
    const writes = await Promise.allSettled([...pendingWrites]);
    const failures = writes.filter((result) => result.status === "rejected");
    capturedStream?.getTracks().forEach((track) => track.stop());
    await playbackContext?.close().catch(() => void 0);
    playbackContext = void 0;
    capturedStream = void 0;
    recorder = void 0;
    activeSessionId = void 0;
    mediaLimitReached = false;
    if (stopError) throw stopError;
    if (failures.length) throw new Error(`\u5A92\u4F53\u6570\u636E\u5757\u5199\u5165\u5931\u8D25 (MEDIA_CHUNK_WRITE_FAILED:${failures.map((failure) => String(failure.reason)).join("; ")})`);
  }
  async function annotateImage(payload) {
    const response = await fetch(payload.dataUrl);
    const bitmap = await createImageBitmap(await response.blob());
    try {
      const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas 2D \u7ED8\u56FE\u4E0A\u4E0B\u6587\u4E0D\u53EF\u7528");
      context.drawImage(bitmap, 0, 0);
      const x = payload.clientX * (bitmap.width / Math.max(1, payload.viewportWidth));
      const y = payload.clientY * (bitmap.height / Math.max(1, payload.viewportHeight));
      const radius = Math.max(12, Math.min(bitmap.width, bitmap.height) * 0.018);
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.lineWidth = Math.max(7, radius * 0.45);
      context.strokeStyle = "rgba(255,255,255,.95)";
      context.stroke();
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      context.lineWidth = Math.max(3, radius * 0.22);
      context.strokeStyle = "#ef233c";
      context.stroke();
      const blob = await canvas.convertToBlob({ type: "image/png" });
      return await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
      });
    } finally {
      bitmap.close();
    }
  }
  chrome.runtime.onMessage.addListener((raw) => {
    if (!isEnvelope(raw)) return;
    const incoming = raw;
    if (incoming.type === "offscreen/start-media") return startMedia(incoming.payload).then(() => ({ ok: true })).catch((error) => ({ ok: false, error: String(error) }));
    if (incoming.type === "offscreen/stop-media") return stopMedia(incoming.payload.sessionId).then(() => ({ ok: true })).catch((error) => ({ ok: false, error: String(error) }));
    if (incoming.type === "offscreen/status") return Promise.resolve({ ok: true, active: activeSessionId === incoming.payload.sessionId && recorder?.state === "recording" });
    if (incoming.type === "offscreen/annotate-image") return annotateImage(incoming.payload).then((dataUrl) => ({ ok: true, dataUrl })).catch((error) => ({ ok: false, error: String(error) }));
  });
})();
